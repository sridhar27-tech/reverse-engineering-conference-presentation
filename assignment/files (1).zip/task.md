# Tasks: Local Postgres Setup (Dayflow HRMS)

## Milestone 1 — Docker Compose Environment
- [ ] Create project root `docker/` (or root-level) folder for compose setup
- [ ] Write `.env.example` with `POSTGRES_USER`, `POSTGRES_PASSWORD`, `POSTGRES_DB`, `POSTGRES_PORT`
- [ ] Copy to `.env` locally and fill in real dev values
- [ ] Add `.env` and volume artifacts to `.gitignore`
- [ ] Write `docker-compose.yml` with `postgres` service (image, env, ports, volume, healthcheck)
- [ ] Add `adminer` (or `pgAdmin`) service for local DB inspection
- [ ] Create `init/` folder for first-run SQL scripts
- [ ] Run `docker compose up -d` and confirm `postgres` reports healthy
- [ ] Confirm connection via `psql` inside the container
- [ ] Confirm connection via Adminer UI at `localhost:8080`
- [ ] Document start/stop/reset commands in `README.md`

## Milestone 2 — Baseline Schema (init scripts, from PRD entities)
- [ ] `users` table — id, employee_id, email, password_hash, role (admin/employee), email_verified, created_at
- [ ] `employees` table — id, user_id (FK), personal details, job details, profile_picture_url, phone, address
- [ ] `documents` table — id, employee_id (FK), file_url, type
- [ ] `attendance` table — id, employee_id (FK), date, check_in, check_out, status (present/absent/half-day/leave)
- [ ] `leave_requests` table — id, employee_id (FK), leave_type (paid/sick/unpaid), start_date, end_date, remarks, status (pending/approved/rejected), reviewed_by, comments
- [ ] `payroll` table — id, employee_id (FK), salary_structure (JSON or normalized), effective_date, updated_by
- [ ] Add seed script with a sample admin + employee for local testing
- [ ] Verify all init scripts run cleanly on `docker compose down -v && docker compose up -d`

## Milestone 3 — App Integration
- [ ] Add `DATABASE_URL` to backend app's env config, pointing to local compose Postgres
- [ ] Wire up ORM/migration tool (e.g., Prisma/TypeORM/Sequelize/SQLAlchemy/Knex — pick per stack) to this DB
- [ ] Run first migration against local Postgres and confirm tables match schema above
- [ ] Add a `docker compose up -d postgres` step to the project's local dev setup docs

## Milestone 4 — Auth & Core Flows (from PRD §3.1–3.6, backend groundwork)
- [ ] Sign Up endpoint — employee ID, email, password, role; enforce password rules; trigger email verification
- [ ] Sign In endpoint — email/password; proper error messages on failure
- [ ] Role-based access middleware (Admin vs Employee)
- [ ] Employee profile: view + limited-field edit (address, phone, picture)
- [ ] Admin: full employee profile edit
- [ ] Attendance: check-in/check-out endpoint; daily/weekly view endpoint
- [ ] Attendance: admin view across all employees
- [ ] Leave: apply (type, date range, remarks) with status defaulting to pending
- [ ] Leave: admin approve/reject with comments; reflect status immediately
- [ ] Payroll: read-only employee view endpoint
- [ ] Payroll: admin update salary structure endpoint
- [ ] Notifications: email/alert hook for leave status changes (stub acceptable for local dev)

## Notes
- Milestones 1–2 are the immediate scope for "local Postgres via Docker Compose."
- Milestones 3–4 are natural next steps derived from the PRD and included for planning continuity.
