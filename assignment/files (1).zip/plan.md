# Plan: Local PostgreSQL via Docker Compose — Dayflow HRMS

## 1. Goal
Stand up a local, disposable PostgreSQL instance for developing the Dayflow HRMS backend (auth, employee profiles, attendance, leave, payroll) without installing Postgres natively.

## 2. Approach
- Use `docker-compose.yml` with a single `postgres` service (official `postgres` image).
- Persist data with a named Docker volume so data survives container restarts.
- Expose Postgres on a host port (default `5432`, configurable) for local app/ORM connections.
- Store credentials and DB name in a `.env` file (gitignored) referenced by compose via `env_file`.
- Optionally add `pgAdmin` (or `adminer`) as a second service for a lightweight DB UI.
- Add a healthcheck so dependent app containers can wait for Postgres to be ready.
- Add an `init.sql` (or `/docker-entrypoint-initdb.d`) mount point for baseline schema/seed scripts (users, employees, attendance, leave_requests, payroll tables) matching the HRMS entities from the PRD.

## 3. Files to create
- `docker-compose.yml` — service definitions (postgres, adminer)
- `.env` — POSTGRES_USER, POSTGRES_PASSWORD, POSTGRES_DB, POSTGRES_PORT
- `.env.example` — committed template of the above
- `.gitignore` — excludes `.env` and volume data
- `init/` — folder for `.sql` init scripts run on first container start
- `README.md` (optional) — how to start/stop/reset the DB

## 4. docker-compose.yml (reference)
```yaml
services:
  postgres:
    image: postgres:16-alpine
    container_name: dayflow_postgres
    restart: unless-stopped
    env_file: .env
    environment:
      POSTGRES_USER: ${POSTGRES_USER}
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
      POSTGRES_DB: ${POSTGRES_DB}
    ports:
      - "${POSTGRES_PORT:-5432}:5432"
    volumes:
      - dayflow_pg_data:/var/lib/postgresql/data
      - ./init:/docker-entrypoint-initdb.d
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ${POSTGRES_USER} -d ${POSTGRES_DB}"]
      interval: 5s
      timeout: 5s
      retries: 10

  adminer:
    image: adminer:latest
    container_name: dayflow_adminer
    restart: unless-stopped
    ports:
      - "8080:8080"
    depends_on:
      - postgres

volumes:
  dayflow_pg_data:
```

## 5. Connection string (for app / ORM)
```
postgresql://<POSTGRES_USER>:<POSTGRES_PASSWORD>@localhost:<POSTGRES_PORT>/<POSTGRES_DB>
```

## 6. Verification steps
1. `docker compose up -d`
2. `docker compose ps` — confirm `postgres` is `healthy`
3. `docker exec -it dayflow_postgres psql -U <user> -d <db>` — confirm shell access
4. Open `http://localhost:8080` (Adminer) — confirm DB browsing works
5. Run app migrations against the connection string above

## 7. Reset / teardown
- `docker compose down` — stop containers, keep data volume
- `docker compose down -v` — stop containers and wipe data volume (fresh start)

## 8. Out of scope for this plan
- Production Postgres configuration (backups, replication, TLS)
- Actual schema/migration definitions (tracked separately, e.g. via ORM migrations)
- CI database provisioning
