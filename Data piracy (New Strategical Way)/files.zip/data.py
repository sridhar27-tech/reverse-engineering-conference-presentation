"""
Data loading for suicide risk text classification.

Uses a public, pre-labeled dataset hosted on the Hugging Face Hub:
"vibhorag101/suicide_prediction_dataset_phr" — derived from the well-known
"Suicide_Detection.csv" Reddit corpus (r/SuicideWatch vs r/teenagers /
r/depression non-suicide posts), binary labels: suicide / non-suicide.

If that dataset is ever unavailable, the loader falls back to
"SetFit/suicide-watch", another public mirror with the same schema.

Run this file directly to sanity check the data pipeline:
    python src/data.py
"""

from datasets import load_dataset, DatasetDict
from transformers import AutoTokenizer

PRIMARY_DATASET = "vibhorag101/suicide_prediction_dataset_phr"
FALLBACK_DATASET = "SetFit/suicide-watch"

LABEL2ID = {"non-suicide": 0, "suicide": 1}
ID2LABEL = {v: k for k, v in LABEL2ID.items()}


def load_raw_dataset() -> DatasetDict:
    """Load the public dataset, trying primary then fallback source."""
    try:
        ds = load_dataset(PRIMARY_DATASET)
    except Exception as e:
        print(f"[data] Primary dataset failed ({e}); trying fallback: {FALLBACK_DATASET}")
        ds = load_dataset(FALLBACK_DATASET)

    # Normalize column names across possible dataset schemas.
    if "text" not in ds["train"].column_names:
        text_col = [c for c in ds["train"].column_names if "text" in c.lower()][0]
        ds = ds.rename_column(text_col, "text")

    label_col_candidates = [c for c in ds["train"].column_names if "label" in c.lower() or "class" in c.lower()]
    if label_col_candidates and label_col_candidates[0] != "label":
        ds = ds.rename_column(label_col_candidates[0], "label")

    # If labels are strings ("suicide"/"non-suicide"), map to ints.
    sample_label = ds["train"][0]["label"]
    if isinstance(sample_label, str):
        def map_label(example):
            example["label"] = LABEL2ID.get(example["label"].strip().lower(), 0)
            return example
        ds = ds.map(map_label)

    return ds


def make_splits(ds: DatasetDict, seed: int = 42, val_frac: float = 0.1, test_frac: float = 0.1) -> DatasetDict:
    """Create train/val/test splits if the dataset doesn't already have them."""
    if set(["train", "validation", "test"]).issubset(ds.keys()):
        return ds

    base = ds["train"] if "train" in ds else list(ds.values())[0]
    split1 = base.train_test_split(test_size=val_frac + test_frac, seed=seed, stratify_by_column="label")
    rel_test = test_frac / (val_frac + test_frac)
    split2 = split1["test"].train_test_split(test_size=rel_test, seed=seed, stratify_by_column="label")

    return DatasetDict(
        train=split1["train"],
        validation=split2["train"],
        test=split2["test"],
    )


def tokenize_dataset(ds: DatasetDict, model_name: str = "mental/mental-bert-base-uncased", max_length: int = 256):
    """Tokenize text for the given transformer model."""
    tokenizer = AutoTokenizer.from_pretrained(model_name)

    def tokenize_fn(batch):
        return tokenizer(batch["text"], truncation=True, max_length=max_length, padding="max_length")

    tokenized = ds.map(tokenize_fn, batched=True)
    tokenized = tokenized.remove_columns([c for c in tokenized["train"].column_names
                                           if c not in ("input_ids", "attention_mask", "token_type_ids", "label")])
    tokenized.set_format("torch")
    return tokenized, tokenizer


if __name__ == "__main__":
    raw = load_raw_dataset()
    splits = make_splits(raw)
    print(splits)
    print("Example row:", splits["train"][0])
    print("Label distribution (train):")
    import collections
    print(collections.Counter(splits["train"]["label"]))
