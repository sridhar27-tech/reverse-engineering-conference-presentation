"""
Inference CLI: run a fine-tuned model on new text and apply a simple
human-escalation policy on top of the raw risk score.

This is a decision-support layer, NOT an autonomous clinical decision-maker.
Any deployment of this code in a real setting must sit behind human review —
see README for the required safety wrapper before any real-world use.

Usage:
    python src/predict.py --model_dir ./outputs/model --text "some input text"
"""

import argparse
import json

from explain import RiskExplainer

# Thresholds are illustrative placeholders only — must be calibrated against
# a validation set (and ideally clinician input) before any real use.
LOW_RISK_MAX = 0.35
MEDIUM_RISK_MAX = 0.65


def triage(risk_score: float, confidence: float) -> dict:
    if confidence < 0.55:
        return {"tier": "needs_human_review", "reason": "low model confidence"}
    if risk_score >= MEDIUM_RISK_MAX:
        return {"tier": "high", "reason": "escalate_immediately"}
    elif risk_score >= LOW_RISK_MAX:
        return {"tier": "medium", "reason": "flag_for_review"}
    else:
        return {"tier": "low", "reason": "routine_monitoring"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_dir", default="./outputs/model")
    parser.add_argument("--text", required=True)
    args = parser.parse_args()

    explainer = RiskExplainer(args.model_dir)
    pred = explainer.predict(args.text)
    decision = triage(pred["risk_score"], pred["confidence"])

    result = {**pred, "triage": decision}
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
