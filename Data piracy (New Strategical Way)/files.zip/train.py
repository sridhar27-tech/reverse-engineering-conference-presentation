"""
Fine-tune MentalBERT (falls back to bert-base-uncased if unavailable) for
binary suicide-risk text classification.

Usage:
    python src/train.py --epochs 3 --batch_size 16 --model_name mental/mental-bert-base-uncased

Outputs a fine-tuned model + tokenizer to ./outputs/model/, plus a
metrics.json with accuracy / precision / recall / F1 / ROC-AUC on the test split.
"""

import argparse
import json
import os

import numpy as np
import torch
from sklearn.metrics import (accuracy_score, precision_recall_fscore_support,
                              roc_auc_score, confusion_matrix)
from transformers import (AutoModelForSequenceClassification, Trainer,
                           TrainingArguments, EarlyStoppingCallback)

from data import load_raw_dataset, make_splits, tokenize_dataset, ID2LABEL


def compute_metrics(eval_pred):
    logits, labels = eval_pred
    probs = torch.softmax(torch.tensor(logits), dim=-1).numpy()
    preds = np.argmax(logits, axis=-1)

    precision, recall, f1, _ = precision_recall_fscore_support(labels, preds, average="binary", zero_division=0)
    acc = accuracy_score(labels, preds)
    try:
        auc = roc_auc_score(labels, probs[:, 1])
    except ValueError:
        auc = float("nan")

    return {"accuracy": acc, "precision": precision, "recall": recall, "f1": f1, "roc_auc": auc}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_name", default="mental/mental-bert-base-uncased",
                         help="HF model id. Falls back to bert-base-uncased if load fails.")
    parser.add_argument("--epochs", type=int, default=3)
    parser.add_argument("--batch_size", type=int, default=16)
    parser.add_argument("--lr", type=float, default=2e-5)
    parser.add_argument("--max_length", type=int, default=256)
    parser.add_argument("--output_dir", default="./outputs/model")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    torch.manual_seed(args.seed)

    print(f"[train] Loading dataset...")
    raw = load_raw_dataset()
    splits = make_splits(raw, seed=args.seed)

    try:
        tokenized, tokenizer = tokenize_dataset(splits, model_name=args.model_name, max_length=args.max_length)
        model = AutoModelForSequenceClassification.from_pretrained(args.model_name, num_labels=2)
    except Exception as e:
        print(f"[train] Could not load {args.model_name} ({e}); falling back to bert-base-uncased")
        args.model_name = "bert-base-uncased"
        tokenized, tokenizer = tokenize_dataset(splits, model_name=args.model_name, max_length=args.max_length)
        model = AutoModelForSequenceClassification.from_pretrained(args.model_name, num_labels=2)

    training_args = TrainingArguments(
        output_dir="./outputs/checkpoints",
        eval_strategy="epoch",
        save_strategy="epoch",
        learning_rate=args.lr,
        per_device_train_batch_size=args.batch_size,
        per_device_eval_batch_size=args.batch_size,
        num_train_epochs=args.epochs,
        weight_decay=0.01,
        load_best_model_at_end=True,
        metric_for_best_model="f1",
        logging_steps=50,
        seed=args.seed,
        report_to=[],  # keep local-only for now; swap for ["mlflow"] once MLOps tracking is wired up
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=tokenized["train"],
        eval_dataset=tokenized["validation"],
        compute_metrics=compute_metrics,
        callbacks=[EarlyStoppingCallback(early_stopping_patience=2)],
    )

    print("[train] Starting fine-tuning...")
    trainer.train()

    print("[train] Evaluating on held-out test set...")
    test_metrics = trainer.evaluate(tokenized["test"])
    preds = trainer.predict(tokenized["test"])
    y_pred = np.argmax(preds.predictions, axis=-1)
    y_true = tokenized["test"]["label"]
    cm = confusion_matrix(y_true, y_pred).tolist()
    test_metrics["confusion_matrix"] = cm
    test_metrics["labels"] = ID2LABEL

    os.makedirs(args.output_dir, exist_ok=True)
    trainer.save_model(args.output_dir)
    tokenizer.save_pretrained(args.output_dir)

    with open(os.path.join(args.output_dir, "..", "metrics.json"), "w") as f:
        json.dump(test_metrics, f, indent=2)

    print(f"[train] Done. Model saved to {args.output_dir}")
    print(f"[train] Test metrics: {json.dumps(test_metrics, indent=2)}")


if __name__ == "__main__":
    main()
