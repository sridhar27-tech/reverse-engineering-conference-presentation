"""
Explainability layer: SHAP token-attribution + attention-weight visualization
for the fine-tuned risk-classification model.

Usage:
    python src/explain.py --model_dir ./outputs/model --text "some input text"

Produces:
    - A SHAP force/text plot saved as HTML (clinician-readable, per-token contribution)
    - An attention heatmap (matplotlib PNG) over the input tokens
    - A JSON explanation record: {text, risk_score, risk_label, top_tokens}
"""

import argparse
import json
import os

import numpy as np
import shap
import torch
import matplotlib.pyplot as plt
from transformers import AutoModelForSequenceClassification, AutoTokenizer

ID2LABEL = {0: "non-suicide", 1: "suicide"}


class RiskExplainer:
    def __init__(self, model_dir: str, device: str = None):
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.tokenizer = AutoTokenizer.from_pretrained(model_dir)
        self.model = AutoModelForSequenceClassification.from_pretrained(
            model_dir, output_attentions=True
        ).to(self.device)
        self.model.eval()

        # SHAP needs a callable that maps list[str] -> np.ndarray of class probabilities
        self._shap_explainer = shap.Explainer(self._predict_proba, self.tokenizer)

    def _predict_proba(self, texts):
        enc = self.tokenizer(list(texts), truncation=True, padding=True,
                              max_length=256, return_tensors="pt").to(self.device)
        with torch.no_grad():
            logits = self.model(**enc).logits
            probs = torch.softmax(logits, dim=-1).cpu().numpy()
        return probs

    def predict(self, text: str) -> dict:
        probs = self._predict_proba([text])[0]
        risk_id = int(np.argmax(probs))
        return {
            "text": text,
            "risk_label": ID2LABEL[risk_id],
            "risk_score": float(probs[1]),  # probability of "suicide" class
            "confidence": float(np.max(probs)),
        }

    def shap_explanation(self, text: str, out_html: str = None):
        shap_values = self._shap_explainer([text])
        if out_html:
            os.makedirs(os.path.dirname(out_html) or ".", exist_ok=True)
            html = shap.plots.text(shap_values[0], display=False)
            with open(out_html, "w") as f:
                f.write(html)
        # Extract top contributing tokens for the "suicide" class (index 1)
        tokens = shap_values[0].data
        vals = shap_values[0].values[:, 1] if shap_values[0].values.ndim > 1 else shap_values[0].values
        ranked = sorted(zip(tokens, vals), key=lambda x: abs(x[1]), reverse=True)[:10]
        return [{"token": t, "shap_value": float(v)} for t, v in ranked]

    def attention_heatmap(self, text: str, out_png: str = None, layer: int = -1):
        enc = self.tokenizer(text, truncation=True, max_length=256, return_tensors="pt").to(self.device)
        with torch.no_grad():
            outputs = self.model(**enc)
        attentions = outputs.attentions[layer][0]  # (num_heads, seq_len, seq_len)
        avg_attn = attentions.mean(dim=0).cpu().numpy()  # average over heads
        tokens = self.tokenizer.convert_ids_to_tokens(enc["input_ids"][0])

        # Attention each token pays to the [CLS] token is a common proxy for token importance
        cls_attention = avg_attn[0]  # row 0 = attention FROM [CLS]

        fig, ax = plt.subplots(figsize=(max(8, len(tokens) * 0.4), 3))
        ax.bar(range(len(tokens)), cls_attention, color="#2563eb")
        ax.set_xticks(range(len(tokens)))
        ax.set_xticklabels(tokens, rotation=75, ha="right", fontsize=8)
        ax.set_ylabel("Attention from [CLS]")
        ax.set_title("Token importance (last-layer attention)")
        plt.tight_layout()

        if out_png:
            os.makedirs(os.path.dirname(out_png) or ".", exist_ok=True)
            plt.savefig(out_png, dpi=150)
        plt.close(fig)
        return dict(zip(tokens, cls_attention.tolist()))

    def full_explanation(self, text: str, out_dir: str = "./outputs/explanations"):
        os.makedirs(out_dir, exist_ok=True)
        pred = self.predict(text)
        top_shap = self.shap_explanation(text, out_html=os.path.join(out_dir, "shap.html"))
        attn = self.attention_heatmap(text, out_png=os.path.join(out_dir, "attention.png"))

        record = {**pred, "top_shap_tokens": top_shap}
        with open(os.path.join(out_dir, "explanation.json"), "w") as f:
            json.dump(record, f, indent=2)
        return record


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--model_dir", default="./outputs/model")
    parser.add_argument("--text", required=True)
    parser.add_argument("--out_dir", default="./outputs/explanations")
    args = parser.parse_args()

    explainer = RiskExplainer(args.model_dir)
    record = explainer.full_explanation(args.text, out_dir=args.out_dir)
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
