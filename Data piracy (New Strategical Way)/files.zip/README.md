# Suicide Risk Prediction with Clinical Explainability — Core Model

Text-based suicide-risk classifier (MentalBERT fine-tune) with SHAP + attention
explainability and a simple human-escalation triage layer.

**This is a research prototype for a college project, not a clinical tool.**
It must never be used to make real decisions about a real person without a
licensed professional in the loop.

## Setup

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

Requires internet access to Hugging Face Hub on first run (downloads dataset +
base model weights, then caches locally).

## Project structure

```
src/
  data.py      # loads public dataset, builds train/val/test splits, tokenizes
  train.py     # fine-tunes MentalBERT for binary classification
  explain.py   # SHAP + attention-based explanations for a prediction
  predict.py   # CLI inference + risk-tier triage logic
outputs/
  model/           # saved fine-tuned model + tokenizer (created by train.py)
  metrics.json     # test-set accuracy/precision/recall/F1/ROC-AUC
  explanations/     # per-prediction SHAP html + attention png + json
```

## Dataset

Public Reddit-derived corpus (`vibhorag101/suicide_prediction_dataset_phr`,
falls back to `SetFit/suicide-watch` if unavailable): posts labeled
`suicide` / `non-suicide`. Run `python src/data.py` on its own first to
sanity-check the split sizes and label balance before training.

**Known limitation (carry this into your report):** this dataset is
English-only, Reddit-only, and not clinically validated — see the
"Research Limitations" slide in your deck. It's good enough to prove the
pipeline works, not to claim clinical accuracy.

## Run order

```bash
# 1. Sanity check the data pipeline
python src/data.py

# 2. Fine-tune the model (uses GPU automatically if available)
python src/train.py --epochs 3 --batch_size 16

# 3. Run inference + get an explanation for one piece of text
python src/predict.py --model_dir ./outputs/model --text "I don't see the point anymore"

# 4. Generate the full explanation artifacts (SHAP html + attention heatmap)
python src/explain.py --model_dir ./outputs/model --text "I don't see the point anymore"
```

## What's implemented vs. what's still a placeholder

| Component | Status |
|---|---|
| Data loading + stratified splits | Done |
| MentalBERT fine-tuning (falls back to BERT if MentalBERT unavailable) | Done |
| SHAP token attribution | Done |
| Attention-based token importance | Done |
| Risk-tier triage (low/medium/high + "needs human review" on low confidence) | Done, thresholds are **placeholders** — must be calibrated |
| Quantization / pruning for on-device inference | Not yet — next step, see below |
| MLflow experiment tracking | Not yet — `report_to=[]` in `train.py` is the hook point |
| Docker containerization | Not yet |
| ONNX / TFLite export | Not yet |

## Suggested next steps (in order)

1. Get `train.py` running end-to-end on the real dataset and record baseline
   metrics in `metrics.json` — this is your first real result.
2. Swap `report_to=[]` for MLflow tracking (`pip install mlflow`, wrap
   `trainer.train()` in an `mlflow.start_run()` block) — gives you the
   experiment-tracking piece for the MLOps story.
3. Calibrate the `LOW_RISK_MAX` / `MEDIUM_RISK_MAX` thresholds in
   `predict.py` against your validation set's precision/recall tradeoff.
4. Add `optimum` + ONNX export for the quantization/pruning claim, then
   benchmark before/after latency and file size — you'll want real numbers
   for the deployment slide.
5. Wrap `predict.py` in a minimal FastAPI service, then Dockerize it.

## Safety note

If you extend this beyond a class project: never ship a numeric risk score
to an end user without a human-escalation path, and treat every
low-confidence prediction as "needs human review," not as a negative result.
