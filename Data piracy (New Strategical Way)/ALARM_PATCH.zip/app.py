"""
CrisisFormer Frontend – Phase 3 + Self-Check Mode
- Analyze text
- High-risk on-screen alert + sound
- Self-Check: label Correct/Incorrect → live accuracy
- Optional Telegram notify (YOUR bot only – not spoof)

Run: python -m streamlit run app.py
"""

import json
from datetime import datetime
from pathlib import Path

import streamlit as st
import streamlit.components.v1 as components
import requests
import plotly.express as px
import pandas as pd

st.set_page_config(page_title="CrisisFormer XAI", page_icon="🧠", layout="wide")

LOG_DIR = Path(__file__).resolve().parent.parent / "outputs"
LOG_DIR.mkdir(parents=True, exist_ok=True)
LOG_FILE = LOG_DIR / "self_check_log.json"

st.markdown("""
<style>
.main-title { font-size: 2.2rem; font-weight: 700; color: #1e3a5f; }
.risk-box { padding: 1.3rem; border-radius: 12px; text-align: center; font-size: 1.7rem; font-weight: bold; margin: 1rem 0; }
.disclaimer { background-color: #fff3cd; border-left: 6px solid #ffc107; padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem; }
.alert-box {
  background: #f8d7da; border: 3px solid #dc3545; color: #721c24;
  padding: 1.5rem; border-radius: 12px; text-align: center;
  font-size: 1.4rem; font-weight: bold; animation: pulse 1.2s infinite;
}
@keyframes pulse {
  0% { box-shadow: 0 0 0 0 rgba(220,53,69,0.6); }
  70% { box-shadow: 0 0 0 14px rgba(220,53,69,0); }
  100% { box-shadow: 0 0 0 0 rgba(220,53,69,0); }
}
</style>
""", unsafe_allow_html=True)

# ---------- Session state ----------
if "history" not in st.session_state:
    st.session_state.history = []
if "last_result" not in st.session_state:
    st.session_state.last_result = None
if "last_text" not in st.session_state:
    st.session_state.last_text = ""

def load_log():
    if LOG_FILE.exists():
        try:
            return json.loads(LOG_FILE.read_text())
        except Exception:
            return []
    return []

def save_log(entries):
    LOG_FILE.write_text(json.dumps(entries, indent=2))

def accuracy_from(entries):
    labeled = [e for e in entries if e.get("user_label") in ("correct", "incorrect")]
    if not labeled:
        return None, 0
    correct = sum(1 for e in labeled if e["user_label"] == "correct")
    return correct / len(labeled), len(labeled)

def play_alert_sound():
    """Automatic high-risk alarm – no manual click required."""
    alarm_path = Path(__file__).resolve().parent / "alarm.wav"
    b64 = ""
    if alarm_path.exists():
        import base64
        b64 = base64.b64encode(alarm_path.read_bytes()).decode("ascii")

    # Autoplay WAV + JS siren (browsers often block silent autoplay;
    # this runs immediately when the high-risk result is rendered)
    audio_tag = ""
    if b64:
        audio_tag = f'''
        <audio id="crisis-alarm" autoplay preload="auto">
          <source src="data:audio/wav;base64,{b64}" type="audio/wav">
        </audio>
        '''

    components.html(
        f'''
        {audio_tag}
        <script>
        (function() {{
          function playSiren() {{
            try {{
              const AudioCtx = window.AudioContext || window.webkitAudioContext;
              const ctx = new AudioCtx();
              if (ctx.state === "suspended") {{ ctx.resume(); }}
              function beep(freq, start, dur) {{
                const o = ctx.createOscillator();
                const g = ctx.createGain();
                o.type = "square";
                o.frequency.value = freq;
                g.gain.value = 0.0001;
                o.connect(g);
                g.connect(ctx.destination);
                o.start(ctx.currentTime + start);
                g.gain.exponentialRampToValueAtTime(0.3, ctx.currentTime + start + 0.03);
                g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + start + dur);
                o.stop(ctx.currentTime + start + dur + 0.05);
              }}
              // 3 rounds of alarm
              for (let r = 0; r < 3; r++) {{
                const off = r * 1.3;
                beep(880, off + 0.0, 0.2);
                beep(1175, off + 0.25, 0.2);
                beep(880, off + 0.5, 0.2);
                beep(1175, off + 0.75, 0.25);
              }}
            }} catch (e) {{ console.log("siren error", e); }}
          }}
          const a = document.getElementById("crisis-alarm");
          if (a) {{
            a.volume = 1.0;
            const p = a.play();
            if (p && p.catch) {{ p.catch(function() {{ playSiren(); }}); }}
          }}
          playSiren();
        }})();
        </script>
        <div style="color:#721c24;font-weight:bold;padding:4px 0;">🔊 Automatic alarm triggered</div>
        ''',
        height=50,
    )


def send_telegram(bot_token: str, chat_id: str, message: str) -> bool:
    """Real Telegram API to YOUR bot – not spoofing."""
    if not bot_token or not chat_id:
        return False
    try:
        url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
        r = requests.post(url, json={"chat_id": chat_id, "text": message}, timeout=10)
        return r.status_code == 200
    except Exception:
        return False

# ---------- Sidebar ----------
with st.sidebar:
    st.title("🧠 CrisisFormer")
    st.markdown("**Self-Check Mode + XAI**")
    st.markdown("---")
    api_url = st.text_input("Backend API URL", value="http://localhost:8000")
    st.markdown("---")
    st.markdown("### Live Accuracy")
    all_log = load_log() + st.session_state.history
    acc, n = accuracy_from(all_log)
    if acc is None:
        st.write("No labels yet. Analyze text, then mark Correct/Incorrect.")
    else:
        st.metric("Self-Check Accuracy", f"{acc:.1%}", help=f"Based on {n} labeled checks")
        st.progress(min(1.0, acc))
    st.markdown("---")
    st.markdown("### Optional Telegram (your bot only)")
    enable_tg = st.checkbox("Send alert to my Telegram", value=False)
    bot_token = st.text_input("Bot token", type="password", disabled=not enable_tg)
    chat_id = st.text_input("Chat ID", disabled=not enable_tg)
    st.caption("Create a bot via @BotFather. No spoofing — only your account.")
    st.markdown("---")
    st.info("Research prototype only.\nYou submit text yourself.\nNot clinical use.")

# ---------- Header ----------
st.markdown('<p class="main-title">CrisisFormer XAI</p>', unsafe_allow_html=True)
st.markdown("**Explainable Suicide Risk Prediction + Self-Check Accuracy**")

st.markdown("""
<div class="disclaimer">
⚠️ <b>Disclaimer:</b> Research prototype only. Not a medical device.
Only analyzes text <b>you</b> enter. Always consult qualified professionals in a real crisis.
</div>
""", unsafe_allow_html=True)

tab1, tab2 = st.tabs(["🔍 Analyze & Self-Check", "📊 Accuracy Log"])

with tab1:
    user_text = st.text_area(
        "Enter text / your search query to analyze:",
        height=140,
        placeholder="Paste any text or a search phrase you want to test...",
    )

    if st.button("🔍 Analyze", type="primary", use_container_width=True):
        if not user_text.strip():
            st.warning("Please enter some text.")
        else:
            with st.spinner("Running DistilBERT + multi-layer explainability..."):
                try:
                    response = requests.post(
                        f"{api_url}/predict",
                        json={"text": user_text, "explain": True},
                        timeout=60,
                    )
                    if response.status_code != 200:
                        st.error(f"Backend error: {response.text}")
                    else:
                        data = response.json()
                        st.session_state.last_result = data
                        st.session_state.last_text = user_text
                except requests.exceptions.ConnectionError:
                    st.error(
                        "Cannot connect to backend.\n"
                        "Start it with:\n"
                        "cd backend\n"
                        "python -m uvicorn main:app --reload --port 8000"
                    )
                except Exception as e:
                    st.error(f"Error: {e}")

    # Show last result
    data = st.session_state.last_result
    if data:
        label = data["predicted_label"]
        is_risk = "Suicide" in label

        if is_risk:
            st.markdown(
                '<div class="alert-box">⚠️ HIGH RISK ALERT — Human review recommended</div>',
                unsafe_allow_html=True,
            )
            play_alert_sound()
            if enable_tg and bot_token and chat_id:
                msg = (
                    f"CrisisFormer Alert\n"
                    f"Predicted: {label}\n"
                    f"Text preview: {st.session_state.last_text[:120]}...\n"
                    f"Time: {datetime.utcnow().isoformat()}Z\n"
                    f"(Research prototype – not clinical)"
                )
                ok = send_telegram(bot_token, chat_id, msg)
                if ok:
                    st.success("Telegram alert sent to your account.")
                else:
                    st.warning("Telegram send failed. Check bot token / chat id.")
        else:
            bg, fg = "#d4edda", "#155724"
            st.markdown(
                f'<div class="risk-box" style="background:{bg}; color:{fg}; border:2px solid {fg};">'
                f"Predicted: {label}</div>",
                unsafe_allow_html=True,
            )

        if data.get("keyword_boost_applied"):
            st.info("Clinical keyword signal contributed to the score.")

        # Probability chart
        st.subheader("Risk Probability")
        probs = data["probabilities"]
        df = pd.DataFrame({"Class": list(probs.keys()), "Probability": list(probs.values())})
        fig = px.bar(
            df,
            x="Class",
            y="Probability",
            color="Class",
            color_discrete_map={"Non-Suicide": "#28a745", "Suicide Risk": "#dc3545"},
            text=df["Probability"].apply(lambda x: f"{x:.1%}"),
            height=320,
        )
        fig.update_traces(textposition="outside")
        fig.update_layout(showlegend=False, yaxis=dict(range=[0, 1.15]))
        st.plotly_chart(fig, use_container_width=True)

        # Explainability
        st.subheader("Multi-Layer Explainability")
        c1, c2, c3 = st.columns(3)

        def show_expl(col, title, block):
            with col:
                st.markdown(f"**{title}**")
                if block and block.get("top_tokens"):
                    tokens = [t["token"] for t in block["top_tokens"]]
                    scores = [t["score"] for t in block["top_tokens"]]
                    df_t = pd.DataFrame({"Token": tokens, "Score": scores})
                    fig_t = px.bar(
                        df_t, x="Score", y="Token", orientation="h",
                        color="Score", color_continuous_scale="Reds", height=300,
                    )
                    fig_t.update_layout(yaxis=dict(autorange="reversed"), showlegend=False)
                    st.plotly_chart(fig_t, use_container_width=True)
                    st.caption(block.get("method", ""))
                else:
                    st.info("No data")

        show_expl(c1, "Attention", data.get("attention"))
        show_expl(c2, "SHAP-style", data.get("shap"))
        show_expl(c3, "LIME-style", data.get("lime"))

        # Self-Check labels
        st.subheader("Self-Check (for accuracy)")
        st.caption("Mark whether the model prediction matches your judgment for this text.")
        col_a, col_b, col_c = st.columns(3)
        with col_a:
            if st.button("✅ Correct", use_container_width=True):
                entry = {
                    "timestamp": datetime.utcnow().isoformat() + "Z",
                    "text": st.session_state.last_text,
                    "predicted": label,
                    "user_label": "correct",
                    "probabilities": probs,
                }
                st.session_state.history.append(entry)
                disk = load_log()
                disk.append(entry)
                save_log(disk)
                st.success("Saved as Correct")
                st.rerun()
        with col_b:
            if st.button("❌ Incorrect", use_container_width=True):
                entry = {
                    "timestamp": datetime.utcnow().isoformat() + "Z",
                    "text": st.session_state.last_text,
                    "predicted": label,
                    "user_label": "incorrect",
                    "probabilities": probs,
                }
                st.session_state.history.append(entry)
                disk = load_log()
                disk.append(entry)
                save_log(disk)
                st.warning("Saved as Incorrect")
                st.rerun()
        with col_c:
            if st.button("Skip label", use_container_width=True):
                st.info("Skipped")

        with st.expander("Full API Response"):
            st.json(data)

with tab2:
    st.subheader("Accuracy Log")
    combined = load_log()
    if not combined:
        st.write("No labeled entries yet.")
    else:
        acc, n = accuracy_from(combined)
        st.metric("Overall Self-Check Accuracy", f"{acc:.1%}" if acc is not None else "N/A")
        st.write(f"Labeled samples: {n}")
        df_log = pd.DataFrame(combined)
        st.dataframe(df_log, use_container_width=True)
        if st.button("Clear log"):
            save_log([])
            st.session_state.history = []
            st.rerun()

st.markdown("---")
st.caption("CrisisFormer • Self-Check Mode • Research prototype • Text submitted by you only")
