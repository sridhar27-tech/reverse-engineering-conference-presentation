# CrisisFormer Live Monitor 2.0 — START HERE

## 1. Backend
Back up your current:
`backend/main.py`

Replace it with:
`backend_upgrade/main.py`

Do NOT replace `src/pipeline.py`.

Start:
`python -m uvicorn main:app --reload --port 8000`

## 2. Edge
Open:
`edge://extensions`

Developer mode -> ON

Remove/reload the old CrisisFormer extension.

Click:
`Load unpacked`

Select:
`browser_extension`

Select the FOLDER, not manifest.json.

## 3. First test
Keep:
- Tracking ON
- Privacy mode ON
- Desktop notification ON
- Desktop alarm ON
- Phone alert OFF

Search for a normal query first. Then test the educational risk examples.

## 4. Phone alert
Optional Telegram support is included in the backend.

Set your own:
`TELEGRAM_BOT_TOKEN`
`TELEGRAM_CHAT_ID`

as Windows environment variables, restart the backend, then turn Phone alert ON.

Never put the bot token inside extension JavaScript.

## 5. Accuracy vs risk
Risk probability = output for the current search.
Accuracy = evaluation metric from a dataset.

The extension intentionally does NOT call a 58.5% risk probability "58.5% accuracy".

## 6. Live monitoring scope
The extension monitors completed search navigations on supported search engines.
It does not capture every character typed into the search box.
This keeps the educational prototype opt-in and substantially limits collection.
