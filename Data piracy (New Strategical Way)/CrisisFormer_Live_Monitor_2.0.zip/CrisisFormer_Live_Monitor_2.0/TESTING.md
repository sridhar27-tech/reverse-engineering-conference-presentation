# Quick testing checklist

1. Start FastAPI.
2. Open `http://127.0.0.1:8000/`.
3. Confirm the API page says it is running.
4. Open `edge://extensions`.
5. Reload CrisisFormer.
6. Open the popup and turn Tracking ON.
7. Search for a normal phrase.
8. Open the popup and confirm "Last search" and risk probability changed.
9. Check the trend card after several searches.
10. Test the desktop alarm/notification using your educational test phrase.
11. Turn Tracking OFF and confirm another search is not analyzed.
12. Confirm Privacy mode is ON before collecting any demonstration screenshots.

If `/metrics` says N/A, that means your project has not saved evaluation metrics
under the filenames/format the endpoint recognizes. It is intentionally not
inventing an accuracy value.
