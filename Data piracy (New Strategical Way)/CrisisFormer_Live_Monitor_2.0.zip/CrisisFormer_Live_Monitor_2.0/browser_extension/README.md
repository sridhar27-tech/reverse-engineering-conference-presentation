# CrisisFormer Self Monitor 2.0

Load this folder directly in Microsoft Edge:
`edge://extensions` -> Developer mode ON -> Load unpacked -> select `browser_extension`.

Features:
- Opt-in ON/OFF monitoring
- Google, Bing, DuckDuckGo, Brave and Yahoo
- Local `/predict` analysis
- Risk probability
- Recent risk history/trend
- Repeated elevated-risk detection
- Desktop notification
- Local alarm
- Optional phone notification through your own Telegram bot
- Privacy mode ON by default
- Clear local history
- Accuracy/precision/recall/F1 only from saved evaluation metrics

Risk probability is NOT model accuracy.
The extension monitors completed searches, not every typed character.
