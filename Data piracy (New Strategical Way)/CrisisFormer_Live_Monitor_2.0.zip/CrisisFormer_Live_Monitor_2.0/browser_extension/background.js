const API = "http://127.0.0.1:8000";

const ENGINES = [
  {hosts:["google."], param:"q", name:"Google"},
  {hosts:["bing."], param:"q", name:"Bing"},
  {hosts:["duckduckgo.com"], param:"q", name:"DuckDuckGo"},
  {hosts:["search.brave.com"], param:"q", name:"Brave"},
  {hosts:["yahoo."], param:"p", name:"Yahoo"}
];

async function settings() {
  return chrome.storage.local.get({
    enabled:false, privacyMode:true, saveQueries:false,
    desktopNotifications:true, desktopAlarm:true, phoneAlerts:false,
    highRiskThreshold:0.75, repeatedRiskThreshold:0.55, repeatedCount:3
  });
}

function searchFromUrl(url) {
  try {
    const u = new URL(url);
    const e = ENGINES.find(x => x.hosts.some(h => u.hostname.includes(h)));
    if (!e) return null;
    const q = u.searchParams.get(e.param);
    return q && q.trim() ? {engine:e.name, query:q.trim()} : null;
  } catch { return null; }
}

function riskOf(r) {
  return Number(r?.probabilities?.["Suicide Risk"] ??
                r?.probabilities?.["High Risk"] ?? 0);
}

async function alarmDocument() {
  try {
    if (chrome.offscreen?.hasDocument && await chrome.offscreen.hasDocument()) return;
    await chrome.offscreen.createDocument({
      url:"alarm.html",
      reasons:["AUDIO_PLAYBACK"],
      justification:"Play an opt-in local research alarm."
    });
  } catch(e) { console.warn(e); }
}

async function playAlarm() {
  await alarmDocument();
  chrome.runtime.sendMessage({type:"PLAY_ALARM"}).catch(()=>{});
}

async function history() {
  return (await chrome.storage.local.get({riskHistory:[]})).riskHistory;
}

async function savePrediction(pred, search, cfg) {
  const h = await history();
  const item = {
    timestamp:new Date().toISOString(),
    engine:search.engine,
    query:(!cfg.privacyMode && cfg.saveQueries) ? search.query : "[redacted]",
    predicted_label:pred.predicted_label,
    risk_probability:riskOf(pred),
    high_risk_alert:Boolean(pred.high_risk_alert)
  };
  h.push(item);
  while (h.length > 100) h.shift();

  await chrome.storage.local.set({
    riskHistory:h,
    lastResult:{...pred, query:item.query, engine:item.engine, timestamp:item.timestamp}
  });
  return h;
}

function trend(h, current, cfg) {
  const recent = h.slice(-5);
  const elevated = recent.filter(x =>
    Number(x.risk_probability) >= Number(cfg.repeatedRiskThreshold)
  ).length;
  const prev = recent.length ? Number(recent[recent.length-1].risk_probability) : null;
  const direction = prev === null ? "new" :
    current > prev + .03 ? "increasing" :
    current < prev - .03 ? "decreasing" : "stable";

  return {
    direction,
    recent_count:recent.length,
    elevated_count:elevated,
    repeated_escalation:
      elevated >= Math.max(1, Number(cfg.repeatedCount)-1) &&
      current >= Number(cfg.repeatedRiskThreshold)
  };
}

async function notifyDesktop(pred, tr, cfg) {
  if (!cfg.desktopNotifications) return;
  const r = riskOf(pred);
  try {
    await chrome.notifications.create("cf-"+Date.now(), {
      type:"basic",
      iconUrl:chrome.runtime.getURL("icon128.png"),
      title:tr.repeated_escalation ?
        "CrisisFormer — repeated elevated signal" :
        "CrisisFormer — high-risk signal",
      message:`Risk probability: ${(r*100).toFixed(1)}%\nTrend: ${tr.direction}\nEducational self-monitoring only.`,
      priority:2
    });
  } catch(e) { console.warn(e); }
}

async function notifyPhone(pred, tr, cfg) {
  if (!cfg.phoneAlerts) return;
  try {
    await fetch(`${API}/notify`, {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({
        label:pred.predicted_label,
        risk_probability:riskOf(pred),
        trend:tr
      })
    });
  } catch(e) {
    await chrome.storage.local.set({phoneAlertError:String(e)});
  }
}

async function analyze(search) {
  const cfg = await settings();
  if (!cfg.enabled) return;

  try {
    const res = await fetch(`${API}/predict`, {
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify({text:search.query, explain:false})
    });
    if (!res.ok) throw new Error(`Backend HTTP ${res.status}`);

    const pred = await res.json();
    const h = await savePrediction(pred, search, cfg);
    const r = riskOf(pred);
    const tr = trend(h, r, cfg);

    const alert =
      Boolean(pred.high_risk_alert) ||
      r >= Number(cfg.highRiskThreshold) ||
      tr.repeated_escalation;

    await chrome.storage.local.set({
      backendOnline:true, lastError:"", lastTrend:tr
    });

    if (alert) {
      await notifyDesktop(pred, tr, cfg);
      await notifyPhone(pred, tr, cfg);
      if (cfg.desktopAlarm) await playAlarm();
    }
  } catch(e) {
    console.error("CrisisFormer:", e);
    await chrome.storage.local.set({
      backendOnline:false, lastError:String(e)
    });
  }
}

chrome.tabs.onUpdated.addListener(async (_tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete" || !tab.url) return;

  const search = searchFromUrl(tab.url);
  if (!search) return;

  const old = await chrome.storage.local.get({lastProcessedUrl:""});
  if (old.lastProcessedUrl === tab.url) return;

  await chrome.storage.local.set({lastProcessedUrl:tab.url});
  await analyze(search);
});

chrome.runtime.onMessage.addListener(msg => {
  if (msg?.type === "STOP_ALARM") {
    chrome.runtime.sendMessage({type:"STOP_ALARM"}).catch(()=>{});
  }
});
