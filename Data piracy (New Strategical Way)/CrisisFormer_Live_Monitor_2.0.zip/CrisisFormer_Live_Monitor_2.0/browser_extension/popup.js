const $=id=>document.getElementById(id);
const defaults={
 enabled:false,privacyMode:true,saveQueries:false,
 desktopNotifications:true,desktopAlarm:true,phoneAlerts:false,
 highRiskThreshold:.75,repeatedRiskThreshold:.55,repeatedCount:3,
 lastResult:null,riskHistory:[]
};

async function state(){return chrome.storage.local.get(defaults);}
function esc(v){const d=document.createElement("div");d.textContent=v??"";return d.innerHTML;}
function risk(r){return Number(r?.probabilities?.["Suicide Risk"]??r?.probabilities?.["High Risk"]??0);}

async function render(){
 const d=await state();
 $("status").innerHTML=d.enabled?'<span class="on">🟢 Tracking is ON</span>':'<span class="off">🔴 Tracking is OFF</span>';
 $("toggle").textContent=d.enabled?"Turn Tracking OFF":"Turn Tracking ON";

 for(const id of ["privacyMode","saveQueries","desktopNotifications","desktopAlarm","phoneAlerts"])
   $(id).checked=d[id];
 for(const id of ["highRiskThreshold","repeatedRiskThreshold","repeatedCount"])
   $(id).value=d[id];

 if(!d.lastResult) $("result").textContent="No search analyzed yet.";
 else{
   const r=risk(d.lastResult);
   $("result").innerHTML=
    `<b>Last search:</b> ${esc(d.lastResult.query)}<br><br>`+
    `<b>Prediction:</b> ${esc(d.lastResult.predicted_label)}<br>`+
    `<span class="metric">Risk probability: ${(r*100).toFixed(1)}%</span><br>`+
    (d.lastResult.high_risk_alert?'<span class="warn">🚨 HIGH-RISK SIGNAL</span>':'<span class="good">No high-risk signal</span>');
 }

 const h=d.riskHistory||[];
 if(!h.length) $("trend").textContent="Risk trend: no session data.";
 else{
   const x=h.slice(-5).map(v=>Number(v.risk_probability));
   const avg=x.reduce((a,b)=>a+b,0)/x.length;
   const dir=x.at(-1)>x[0]+.03?"increasing ↑":x.at(-1)<x[0]-.03?"decreasing ↓":"stable →";
   $("trend").innerHTML=
    `<b>Recent risk trend:</b> ${dir}<br>`+
    `Average of last ${x.length}: ${(avg*100).toFixed(1)}%<br>`+
    `Total analyzed: ${h.length}`;
 }

 try{
   const m=await fetch("http://127.0.0.1:8000/metrics").then(r=>r.json());
   const f=v=>v==null?"N/A":v;
   $("metrics").innerHTML=
    `<b>Model evaluation</b><br>`+
    `<span class="metric">Accuracy: ${f(m.accuracy)}</span>`+
    `<span class="metric">Precision: ${f(m.precision)}</span>`+
    `<span class="metric">Recall: ${f(m.recall)}</span>`+
    `<span class="metric">F1: ${f(m.f1)}</span><br>`+
    `<span class="small">${esc(m.source||"")}</span>`;
 }catch{
   $("metrics").textContent="Model evaluation metrics unavailable. No accuracy is invented.";
 }
}

$("toggle").onclick=async()=>{
 const d=await state();
 await chrome.storage.local.set({enabled:!d.enabled});
 render();
};
$("stop").onclick=()=>chrome.runtime.sendMessage({type:"STOP_ALARM"}).catch(()=>{});
$("clear").onclick=async()=>{
 await chrome.storage.local.remove(["riskHistory","lastResult","lastTrend","lastProcessedUrl","lastAlert"]);
 render();
};

for(const id of ["privacyMode","saveQueries","desktopNotifications","desktopAlarm","phoneAlerts"])
 $(id).onchange=e=>chrome.storage.local.set({[id]:e.target.checked});

for(const id of ["highRiskThreshold","repeatedRiskThreshold","repeatedCount"])
 $(id).onchange=e=>{
   let v=Number(e.target.value);
   v=id==="repeatedCount"?Math.max(2,Math.min(10,Math.round(v))):Math.max(0,Math.min(1,v));
   chrome.storage.local.set({[id]:v});
 };

render();
