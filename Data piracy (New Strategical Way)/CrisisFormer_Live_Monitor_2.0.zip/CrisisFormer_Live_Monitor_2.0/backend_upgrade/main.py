"""
CrisisFormer Backend API 2.0
Use this as a replacement for the current backend/main.py.
Run:
python -m uvicorn main:app --reload --port 8000
"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Optional, List, Dict
from pathlib import Path
import sys, os, json, urllib.request, urllib.parse

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))
from pipeline import RiskPipeline

app=FastAPI(
    title="CrisisFormer API",
    description="Explainable Transformer-Based Suicide Risk Detection",
    version="2.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_credentials=True,
    allow_methods=["*"], allow_headers=["*"]
)

CONFIG_PATH=Path(__file__).resolve().parent.parent/"config.yaml"
pipeline=RiskPipeline(str(CONFIG_PATH),num_labels=2)

class TextRequest(BaseModel):
    text:str=Field(...,min_length=1,max_length=2000)
    explain:bool=True

class TokenScore(BaseModel):
    token:str
    score:float

class ExplanationBlock(BaseModel):
    method:str
    top_tokens:List[TokenScore]

class PredictionResponse(BaseModel):
    predicted_label:str
    probabilities:Dict[str,float]
    keyword_boost_applied:bool=False
    attention:Optional[ExplanationBlock]=None
    shap:Optional[ExplanationBlock]=None
    lime:Optional[ExplanationBlock]=None
    high_risk_alert:bool
    disclaimer:str

@app.get("/")
def root():
    return {
        "message":"CrisisFormer Backend is running",
        "model":"DistilBERT + Multi-XAI",
        "status":"active"
    }

@app.get("/health")
def health():
    return {"status":"healthy"}

@app.post("/predict",response_model=PredictionResponse)
def predict(request:TextRequest):
    if not request.text.strip():
        raise HTTPException(status_code=400,detail="Text cannot be empty")
    try:
        result=pipeline.run(request.text,explain=request.explain)
        pred=result["prediction"]
        exp=result.get("explanation") or {}

        def block(x):
            if not x or not x.get("top_tokens"): return None
            return {
                "method":x.get("method",""),
                "top_tokens":[
                    {"token":t[0],"score":round(float(t[1]),4)}
                    for t in x["top_tokens"][:8]
                ]
            }

        return {
            "predicted_label":pred["predicted_label"],
            "probabilities":pred["probabilities"],
            "keyword_boost_applied":pred.get("keyword_boost_applied",False),
            "attention":block(exp.get("attention")),
            "shap":block(exp.get("shap")),
            "lime":block(exp.get("lime")),
            "high_risk_alert":result["flags"]["high_risk_alert"],
            "disclaimer":result["ethics"]["disclaimer"]
        }
    except Exception as e:
        raise HTTPException(status_code=500,detail=str(e))

@app.get("/metrics")
def metrics():
    """
    Reads real saved evaluation metrics.
    It does not calculate accuracy from browser searches.
    """
    out=CONFIG_PATH.parent/"outputs"
    candidates=[
        out/"metrics.json",
        out/"model_metrics.json",
        out/"evaluation_metrics.json",
        out/"evaluation.json"
    ]
    if out.exists():
        candidates += sorted(out.glob("*.json"))

    seen=set()
    for p in candidates:
        if p in seen or not p.exists(): continue
        seen.add(p)
        try:
            d=json.loads(p.read_text(encoding="utf-8"))
            vals={
                "accuracy":d.get("accuracy",d.get("Accuracy")),
                "precision":d.get("precision",d.get("Precision")),
                "recall":d.get("recall",d.get("Recall")),
                "f1":d.get("f1",d.get("F1",d.get("f1_score")))
            }
            if any(v is not None for v in vals.values()):
                vals["source"]=p.name
                return vals
        except Exception:
            pass

    return {
        "accuracy":None,"precision":None,"recall":None,"f1":None,
        "source":"No saved evaluation metrics found."
    }

class NotifyRequest(BaseModel):
    label:str
    risk_probability:float=Field(ge=0,le=1)
    trend:Dict={}

@app.post("/notify")
def notify(request:NotifyRequest):
    """
    Optional Telegram notification to the user's OWN bot/chat.
    Set TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID as environment variables.
    """
    token=os.getenv("TELEGRAM_BOT_TOKEN")
    chat_id=os.getenv("TELEGRAM_CHAT_ID")

    if not token or not chat_id:
        return {"sent":False,"reason":"Telegram credentials are not configured."}

    text=(
        "CrisisFormer self-monitor alert\n"
        f"Prediction: {request.label}\n"
        f"Risk probability: {request.risk_probability*100:.1f}%\n"
        f"Trend: {request.trend.get('direction','new')}\n"
        "Educational prototype — not a diagnosis."
    )

    url=f"https://api.telegram.org/bot{token}/sendMessage"
    body=urllib.parse.urlencode({"chat_id":chat_id,"text":text}).encode()

    try:
        req=urllib.request.Request(url,data=body,method="POST")
        with urllib.request.urlopen(req,timeout=10) as response:
            return {"sent":True,"telegram_status":response.status}
    except Exception as e:
        return {"sent":False,"reason":str(e)}

if __name__=="__main__":
    import uvicorn
    uvicorn.run("main:app",host="0.0.0.0",port=8000,reload=True)
