# CrisisFormer – Explainable Suicide Risk Prediction using Transformer Models

**College Project | Reverse Engineering + Explainable AI | Phases 1–3 Combined**

---

## Project Summary
CrisisFormer predicts suicide risk from text using DistilBERT and explains the decision with:
- Attention visualization
- SHAP-style token importance
- LIME-style local explanations

Frontend: Streamlit | Backend: FastAPI | Model: Fine-tuned DistilBERT

**Overall completion: ~85–90% (Phase 3)**

---

## Phase Overview

| Phase | Focus | Status |
|-------|--------|--------|
| 1 | Architecture, frontend/backend, basic XAI | Done (~50%) |
| 2 | Fine-tuning, metrics, model save | Done (~70%) |
| 3 | Evaluation report, ONNX path, polish | Done (~85–90%) |

---

## Quick Start

```bash
pip install -r requirements.txt

# Train (if models/ folder empty)
cd src && python train_phase2.py

# Evaluate
python evaluate_phase3.py

# Optional ONNX export
python export_onnx_phase3.py

# Run system
# Terminal 1
cd backend && python -m uvicorn main:app --reload --port 8000

# Terminal 2
cd frontend && python -m streamlit run app.py
```

---

## Folder Structure
```
neuroguard_prototype/
├── backend/           # FastAPI
├── frontend/          # Streamlit UI + charts
├── src/
│   ├── crisisformer.py
│   ├── pipeline.py
│   ├── train_phase2.py
│   ├── evaluate_phase3.py
│   └── export_onnx_phase3.py
├── models/
│   └── crisisformer_phase2/   # fine-tuned weights
├── data/
│   └── sample_train.csv
├── docs/
│   ├── PHASE2.md
│   └── PHASE3.md
└── outputs/
```

---

## Sample Results (demo dataset)
- Validation Accuracy: ~92%
- F1 Score: ~0.92
- Metrics file: `models/crisisformer_phase2/metrics.json`

---

## Ethics & Privacy
- Research prototype only – **not a medical device**
- No permanent storage of personal identity
- Human review required for any high-risk flag
- Designed toward on-device / privacy-preserving inference

---

## Team
AI & Data Science – Reverse Engineering Project (Review track)
