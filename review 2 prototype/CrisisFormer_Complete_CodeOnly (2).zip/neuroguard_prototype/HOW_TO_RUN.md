# CrisisFormer – How to Run (Phase 2)

## 1. Install
```bash
cd neuroguard_prototype
pip install -r requirements.txt
```

## 2. Train Phase 2 model (once)
```bash
cd src
python train_phase2.py
```
Saves model to: models/crisisformer_phase2/

## 3. Backend (Terminal 1)
```bash
cd backend
python -m uvicorn main:app --reload --port 8000
```

## 4. Frontend (Terminal 2)
```bash
cd frontend
python -m streamlit run app.py
```

Open http://localhost:8501

## Phase 2 results (sample data)
- Validation Accuracy: ~92%
- F1 Score: ~0.92
- Model auto-loads if models/crisisformer_phase2/ exists

## Overall completion
~70% (Review 2 target)

Research prototype only. Not for clinical use.
