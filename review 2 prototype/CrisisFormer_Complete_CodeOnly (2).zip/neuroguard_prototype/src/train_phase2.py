"""
Phase 2 – Fine-tune DistilBERT for Suicide Risk Prediction
CrisisFormer-style training + evaluation + model saving

Usage:
  cd src
  python train_phase2.py

Outputs:
  ../models/crisisformer_phase2/   (saved model + tokenizer + metrics)
"""

from __future__ import annotations
import json
import random
from pathlib import Path
from datetime import datetime

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
from transformers import (
    DistilBertTokenizerFast,
    DistilBertForSequenceClassification,
    get_linear_schedule_with_warmup,
)
from torch.optim import AdamW
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score,
    precision_recall_fscore_support,
    classification_report,
    confusion_matrix,
)
from tqdm import tqdm

# ====================== CONFIG ======================
MODEL_NAME = "distilbert-base-uncased"
DATA_PATH = Path(__file__).resolve().parent.parent / "data" / "sample_train.csv"
OUTPUT_DIR = Path(__file__).resolve().parent.parent / "models" / "crisisformer_phase2"
MAX_LENGTH = 64
BATCH_SIZE = 2
EPOCHS = 3
LEARNING_RATE = 3e-5
SEED = 42
NUM_LABELS = 2
LABEL_MAP = {0: "Non-Suicide", 1: "Suicide Risk"}
FREEZE_BASE = True  # train classifier head only (CPU-friendly)


def set_seed(seed: int = SEED):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


set_seed()
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"[Phase2] Device: {device}")


class RiskDataset(Dataset):
    def __init__(self, texts, labels, tokenizer, max_length=MAX_LENGTH):
        self.texts = list(texts)
        self.labels = list(labels)
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.texts)

    def __getitem__(self, idx):
        enc = self.tokenizer(
            self.texts[idx],
            truncation=True,
            padding="max_length",
            max_length=self.max_length,
            return_tensors="pt",
        )
        return {
            "input_ids": enc["input_ids"].squeeze(0),
            "attention_mask": enc["attention_mask"].squeeze(0),
            "labels": torch.tensor(self.labels[idx], dtype=torch.long),
        }


def load_data():
    if not DATA_PATH.exists():
        raise FileNotFoundError(f"Dataset not found: {DATA_PATH}")
    df = pd.read_csv(DATA_PATH)
    df = df.dropna(subset=["text", "label"])
    df["label"] = df["label"].astype(int)
    print(f"[Phase2] Loaded {len(df)} samples from {DATA_PATH.name}")
    print(df["label"].value_counts().to_dict())
    return df["text"].tolist(), df["label"].tolist()


def evaluate(model, loader):
    model.eval()
    preds, truths = [], []
    with torch.no_grad():
        for batch in loader:
            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)
            labels = batch["labels"].to(device)
            outputs = model(input_ids=input_ids, attention_mask=attention_mask)
            pred = torch.argmax(outputs.logits, dim=-1)
            preds.extend(pred.cpu().numpy().tolist())
            truths.extend(labels.cpu().numpy().tolist())

    acc = accuracy_score(truths, preds)
    p, r, f1, _ = precision_recall_fscore_support(
        truths, preds, average="weighted", zero_division=0
    )
    report = classification_report(
        truths, preds, target_names=list(LABEL_MAP.values()), zero_division=0
    )
    cm = confusion_matrix(truths, preds).tolist()
    return {
        "accuracy": float(acc),
        "precision": float(p),
        "recall": float(r),
        "f1": float(f1),
        "report": report,
        "confusion_matrix": cm,
        "preds": preds,
        "truths": truths,
    }


def train():
    print("=" * 60)
    print("PHASE 2 – Fine-tuning DistilBERT (CrisisFormer style)")
    print("=" * 60)

    texts, labels = load_data()
    train_texts, val_texts, train_labels, val_labels = train_test_split(
        texts, labels, test_size=0.25, random_state=SEED, stratify=labels
    )

    tokenizer = DistilBertTokenizerFast.from_pretrained(MODEL_NAME)
    model = DistilBertForSequenceClassification.from_pretrained(
        MODEL_NAME, num_labels=NUM_LABELS
    )
    model.to(device)

    if FREEZE_BASE:
        for name, param in model.named_parameters():
            if not name.startswith("classifier") and not name.startswith("pre_classifier"):
                param.requires_grad = False
        print("[Phase2] Base DistilBERT frozen – training classifier head only")

    train_ds = RiskDataset(train_texts, train_labels, tokenizer)
    val_ds = RiskDataset(val_texts, val_labels, tokenizer)
    train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_ds, batch_size=BATCH_SIZE)

    optimizer = AdamW(filter(lambda x: x.requires_grad, model.parameters()), lr=LEARNING_RATE, weight_decay=0.01)
    total_steps = len(train_loader) * EPOCHS
    scheduler = get_linear_schedule_with_warmup(
        optimizer, num_warmup_steps=max(1, total_steps // 10), num_training_steps=total_steps
    )

    best_f1 = -1.0
    history = []

    for epoch in range(1, EPOCHS + 1):
        model.train()
        total_loss = 0.0
        loop = tqdm(train_loader, desc=f"Epoch {epoch}/{EPOCHS}")
        for batch in loop:
            optimizer.zero_grad()
            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)
            labels_t = batch["labels"].to(device)
            outputs = model(
                input_ids=input_ids, attention_mask=attention_mask, labels=labels_t
            )
            loss = outputs.loss
            total_loss += loss.item()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            scheduler.step()
            loop.set_postfix(loss=round(loss.item(), 4))

        avg_loss = total_loss / max(1, len(train_loader))
        metrics = evaluate(model, val_loader)
        history.append({"epoch": epoch, "train_loss": avg_loss, **{k: metrics[k] for k in ["accuracy", "precision", "recall", "f1"]}})

        print(f"\nEpoch {epoch} | Loss: {avg_loss:.4f} | Val Acc: {metrics['accuracy']:.4f} | F1: {metrics['f1']:.4f}")
        print(metrics["report"])

        if metrics["f1"] > best_f1:
            best_f1 = metrics["f1"]
            save_model(model, tokenizer, metrics, history)
            print(f"✓ Best model saved (F1={best_f1:.4f})")

    print("\n" + "=" * 60)
    print(f"Training complete. Best F1: {best_f1:.4f}")
    print(f"Model saved at: {OUTPUT_DIR.resolve()}")
    print("=" * 60)
    return OUTPUT_DIR


def save_model(model, tokenizer, metrics, history):
    import tempfile, shutil
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    # Save via temp dir to avoid intermittent FS issues
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp) / "ckpt"
        tmp_path.mkdir()
        model.save_pretrained(tmp_path, safe_serialization=False)
        tokenizer.save_pretrained(tmp_path)
        for f in tmp_path.iterdir():
            target = OUTPUT_DIR / f.name
            if target.exists():
                target.unlink()
            shutil.copy2(f, target)
    print(f"[Phase2] Files written to {OUTPUT_DIR}")

    meta = {
        "project": "CrisisFormer Phase 2",
        "base_model": MODEL_NAME,
        "num_labels": NUM_LABELS,
        "label_map": LABEL_MAP,
        "trained_at": datetime.utcnow().isoformat() + "Z",
        "metrics": {
            "accuracy": metrics["accuracy"],
            "precision": metrics["precision"],
            "recall": metrics["recall"],
            "f1": metrics["f1"],
            "confusion_matrix": metrics["confusion_matrix"],
        },
        "classification_report": metrics["report"],
        "history": history,
        "notes": "Fine-tuned on sample suicide-risk dataset for Review 2 prototype. Replace sample_train.csv with larger labeled data for production-level accuracy.",
    }
    with open(OUTPUT_DIR / "metrics.json", "w") as f:
        json.dump(meta, f, indent=2)

    with open(OUTPUT_DIR / "label_map.json", "w") as f:
        json.dump(LABEL_MAP, f, indent=2)


def quick_test():
    """Load saved model and run a few predictions."""
    if not (OUTPUT_DIR / "config.json").exists():
        print("No saved model found. Train first.")
        return
    tokenizer = DistilBertTokenizerFast.from_pretrained(OUTPUT_DIR)
    model = DistilBertForSequenceClassification.from_pretrained(OUTPUT_DIR)
    model.to(device)
    model.eval()

    samples = [
        "I had a wonderful day with my family.",
        "I feel completely hopeless and want to die.",
        "Looking forward to the weekend.",
        "Nothing matters anymore I cannot go on.",
    ]
    print("\n[Quick Test after training]")
    for t in samples:
        enc = tokenizer(t, truncation=True, padding=True, max_length=MAX_LENGTH, return_tensors="pt")
        enc = {k: v.to(device) for k, v in enc.items()}
        with torch.no_grad():
            logits = model(**enc).logits
            probs = torch.softmax(logits, dim=-1)[0]
            pred = int(torch.argmax(probs))
        print(f"  [{LABEL_MAP[pred]}] ({probs[1]:.2%} risk)  |  {t[:60]}")


if __name__ == "__main__":
    train()
    quick_test()
