"""
CrisisFormer – Phase 2
DistilBERT + Multi-layer Explainability (Attention + SHAP-style + LIME)

Loads fine-tuned weights from models/crisisformer_phase2/ when available.
"""

from __future__ import annotations
import torch
from torch import nn
from transformers import (
    AutoModel,
    AutoTokenizer,
    AutoConfig,
    DistilBertForSequenceClassification,
    DistilBertTokenizerFast,
)
from typing import Dict, List, Optional
import numpy as np
import yaml
from pathlib import Path

try:
    import shap
    HAS_SHAP = True
except ImportError:
    HAS_SHAP = False

try:
    from lime.lime_text import LimeTextExplainer
    HAS_LIME = True
except ImportError:
    HAS_LIME = False


class CrisisFormerClassifier(nn.Module):
    """Fallback custom head when no fine-tuned checkpoint exists."""

    def __init__(self, model_name: str = "distilbert-base-uncased", num_labels: int = 2):
        super().__init__()
        self.config = AutoConfig.from_pretrained(model_name)
        self.config.attn_implementation = "eager"
        self.distilbert = AutoModel.from_pretrained(
            model_name, config=self.config, attn_implementation="eager"
        )
        self.dropout = nn.Dropout(0.2)
        self.classifier = nn.Linear(self.config.hidden_size, num_labels)

    def forward(self, input_ids, attention_mask, return_attentions: bool = False):
        outputs = self.distilbert(
            input_ids=input_ids,
            attention_mask=attention_mask,
            output_attentions=return_attentions,
            return_dict=True,
        )
        pooled = outputs.last_hidden_state[:, 0]
        pooled = self.dropout(pooled)
        logits = self.classifier(pooled)
        result = {"logits": logits, "pooled": pooled}
        if return_attentions and outputs.attentions is not None:
            result["attentions"] = outputs.attentions
        return result


class CrisisFormer:
    """
    Phase 2 wrapper:
    - Prefers fine-tuned DistilBERT from models/crisisformer_phase2/
    - Falls back to base DistilBERT + custom head
    - Multi-layer explainability: Attention + SHAP-style + LIME
    """

    def __init__(self, config_path: str = "config.yaml", num_labels: int = 2):
        with open(config_path, "r") as f:
            self.cfg = yaml.safe_load(f)

        self.num_labels = num_labels
        self.max_length = self.cfg["model"].get("max_length", 128)
        self.device = torch.device(self.cfg["model"].get("device", "cpu"))
        self.label_map = {0: "Non-Suicide", 1: "Suicide Risk"} if num_labels == 2 else {
            int(k): v for k, v in self.cfg["labels"].items()
        }

        project_root = Path(config_path).resolve().parent
        phase2_dir = project_root / "models" / "crisisformer_phase2"
        self.fine_tuned = phase2_dir.exists() and (phase2_dir / "config.json").exists()
        self.use_hf_model = False

        if self.fine_tuned:
            print(f"[CrisisFormer] Loading FINE-TUNED Phase-2 model from {phase2_dir}")
            self.tokenizer = DistilBertTokenizerFast.from_pretrained(str(phase2_dir))
            self.hf_model = DistilBertForSequenceClassification.from_pretrained(str(phase2_dir))
            self.hf_model.to(self.device)
            self.hf_model.eval()
            self.use_hf_model = True
            self.model = None
            print("[CrisisFormer] Phase-2 fine-tuned model ready")
        else:
            print("[CrisisFormer] No Phase-2 checkpoint found – using base DistilBERT")
            self.model_name = "distilbert-base-uncased"
            self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
            self.model = CrisisFormerClassifier(self.model_name, num_labels)
            self.model.to(self.device)
            self.model.eval()
            self.hf_model = None
            print("[CrisisFormer] Base model ready (run train_phase2.py to fine-tune)")

        self.high_risk_keywords = {
            "die", "suicide", "kill", "hopeless", "end it", "no reason",
            "disappear", "worthless", "can't go on", "end my life",
            "want to die", "better off dead", "no future", "give up",
            "no point", "end it all", "not wake up", "burden",
        }

    def encode(self, texts: List[str]) -> Dict[str, torch.Tensor]:
        encoded = self.tokenizer(
            texts,
            padding=True,
            truncation=True,
            max_length=self.max_length,
            return_tensors="pt",
        )
        return {k: v.to(self.device) for k, v in encoded.items()}

    def _keyword_boost(self, text: str) -> float:
        text_lower = text.lower()
        hits = sum(1 for kw in self.high_risk_keywords if kw in text_lower)
        # Smaller boost when model is already fine-tuned
        scale = 0.08 if self.fine_tuned else 0.12
        return min(0.25 if self.fine_tuned else 0.35, hits * scale)

    @torch.no_grad()
    def predict(self, text: str) -> Dict:
        inputs = self.encode([text])

        if self.use_hf_model:
            outputs = self.hf_model(
                input_ids=inputs["input_ids"],
                attention_mask=inputs["attention_mask"],
            )
            logits = outputs.logits
        else:
            outputs = self.model(
                input_ids=inputs["input_ids"],
                attention_mask=inputs["attention_mask"],
                return_attentions=False,
            )
            logits = outputs["logits"]

        probs = torch.softmax(logits, dim=-1)[0].cpu().numpy()

        boost = self._keyword_boost(text)
        if self.num_labels == 2:
            probs[1] = min(0.98, float(probs[1]) + boost)
            probs[0] = 1.0 - probs[1]
        else:
            probs[3] = min(0.95, float(probs[3]) + boost)
            probs = probs / probs.sum()

        pred_id = int(np.argmax(probs))
        return {
            "text": text,
            "predicted_label": self.label_map[pred_id],
            "predicted_id": pred_id,
            "probabilities": {
                self.label_map[i]: float(probs[i]) for i in range(self.num_labels)
            },
            "keyword_boost_applied": boost > 0.01,
            "model_version": "phase2-finetuned" if self.fine_tuned else "base-prototype",
            "disclaimer": "PROTOTYPE – Research only. Not for clinical use. Always requires human review.",
        }

    @torch.no_grad()
    def explain_attention(self, text: str, top_k: int = 10) -> Dict:
        inputs = self.encode([text])

        if self.use_hf_model:
            # HF model: get attentions from underlying distilbert
            outputs = self.hf_model.distilbert(
                input_ids=inputs["input_ids"],
                attention_mask=inputs["attention_mask"],
                output_attentions=True,
                return_dict=True,
            )
            attentions = outputs.attentions
        else:
            outputs = self.model(
                input_ids=inputs["input_ids"],
                attention_mask=inputs["attention_mask"],
                return_attentions=True,
            )
            attentions = outputs.get("attentions")

        if not attentions:
            return {"top_tokens": [], "method": "attention (unavailable)"}

        last_attn = attentions[-1]  # (1, heads, seq, seq)
        avg_attn = last_attn[0].mean(dim=0)
        # CLS-to-token importance (row 0 or column depending on layout)
        cls_to_tokens = avg_attn[0] if avg_attn.shape[0] > 0 else avg_attn[:, 0]

        tokens = self.tokenizer.convert_ids_to_tokens(inputs["input_ids"][0])
        ranked = []
        for tok, sc in zip(tokens, cls_to_tokens.cpu().numpy()):
            if tok in ("[CLS]", "[SEP]", "[PAD]", "<s>", "</s>", "[UNK]"):
                continue
            clean = tok.replace("##", "")
            ranked.append((clean, float(sc)))

        ranked = sorted(ranked, key=lambda x: x[1], reverse=True)[:top_k]
        return {
            "top_tokens": ranked,
            "method": "DistilBERT last-layer attention (CrisisFormer)",
        }

    def explain_shap(self, text: str, top_k: int = 8) -> Dict:
        """SHAP-style: attention ranking + clinical keyword weighting."""
        attn = self.explain_attention(text, top_k=top_k * 2)
        tokens = attn.get("top_tokens", [])
        boosted = []
        for tok, score in tokens:
            extra = 0.18 if tok.lower() in self.high_risk_keywords else 0.0
            boosted.append((tok, score + extra))
        boosted = sorted(boosted, key=lambda x: x[1], reverse=True)[:top_k]
        return {
            "top_tokens": boosted,
            "method": "SHAP-style (attention + clinical keyword weighting)",
        }

    def explain_lime(self, text: str, top_k: int = 8) -> Dict:
        """LIME-style: word masking importance."""
        words = text.split()
        if len(words) < 2:
            return {"top_tokens": [], "method": "LIME (too short)"}

        base_pred = self.predict(text)
        risk_key = "Suicide Risk" if "Suicide Risk" in base_pred["probabilities"] else list(base_pred["probabilities"].keys())[-1]
        base_score = base_pred["probabilities"][risk_key]

        importances = []
        for i, w in enumerate(words):
            masked = " ".join(words[:i] + ["[MASK]"] + words[i + 1 :])
            new_pred = self.predict(masked)
            new_score = new_pred["probabilities"].get(risk_key, 0.0)
            delta = base_score - new_score
            importances.append((w, float(delta)))

        ranked = sorted(importances, key=lambda x: abs(x[1]), reverse=True)[:top_k]
        return {
            "top_tokens": ranked,
            "method": "LIME-style (word masking importance)",
        }

    def full_explain(self, text: str) -> Dict:
        return {
            "attention": self.explain_attention(text),
            "shap": self.explain_shap(text),
            "lime": self.explain_lime(text),
        }


if __name__ == "__main__":
    cfg = Path(__file__).resolve().parent.parent / "config.yaml"
    cf = CrisisFormer(str(cfg), num_labels=2)
    samples = [
        "I had a good day at work.",
        "I feel completely hopeless and want to die.",
    ]
    for s in samples:
        print(cf.predict(s))
        print(cf.explain_attention(s)["top_tokens"][:5])
        print("---")
