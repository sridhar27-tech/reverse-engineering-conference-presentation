"""
Phase 3 – Model compression / ONNX export
Exports the fine-tuned DistilBERT classifier to ONNX for lighter deployment.
"""

from __future__ import annotations
from pathlib import Path
import torch
from transformers import DistilBertForSequenceClassification, DistilBertTokenizerFast

ROOT = Path(__file__).resolve().parent.parent
MODEL_DIR = ROOT / "models" / "crisisformer_phase2"
ONNX_DIR = ROOT / "models" / "crisisformer_onnx"
MAX_LENGTH = 64


def export():
    if not (MODEL_DIR / "config.json").exists():
        print("Phase-2 model not found. Run: python train_phase2.py")
        return

    print("[Phase3] Loading fine-tuned model...")
    model = DistilBertForSequenceClassification.from_pretrained(str(MODEL_DIR))
    tokenizer = DistilBertTokenizerFast.from_pretrained(str(MODEL_DIR))
    model.eval()

    ONNX_DIR.mkdir(parents=True, exist_ok=True)

    dummy = tokenizer(
        "example text for export",
        return_tensors="pt",
        padding="max_length",
        truncation=True,
        max_length=MAX_LENGTH,
    )

    onnx_path = ONNX_DIR / "crisisformer.onnx"
    print(f"[Phase3] Exporting ONNX to {onnx_path}")

    try:
        torch.onnx.export(
            model,
            (dummy["input_ids"], dummy["attention_mask"]),
            str(onnx_path),
            input_names=["input_ids", "attention_mask"],
            output_names=["logits"],
            dynamic_axes={
                "input_ids": {0: "batch"},
                "attention_mask": {0: "batch"},
                "logits": {0: "batch"},
            },
            opset_version=14,
        )
        # also save tokenizer for runtime
        tokenizer.save_pretrained(ONNX_DIR)
        print("[Phase3] ONNX export successful")
        print(f"  File: {onnx_path} ({onnx_path.stat().st_size / 1e6:.1f} MB)")
    except Exception as e:
        print(f"[Phase3] ONNX export skipped/failed: {e}")
        print("  (Optional dependency / environment limit – PyTorch model still usable)")


if __name__ == "__main__":
    export()
