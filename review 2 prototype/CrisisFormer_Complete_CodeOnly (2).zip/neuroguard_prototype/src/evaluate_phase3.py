"""
Phase 3 – Full evaluation report
Runs predictions on sample data, prints metrics, saves JSON report.
"""

from __future__ import annotations
import json
from pathlib import Path
from datetime import datetime

import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    precision_recall_fscore_support,
    classification_report,
    confusion_matrix,
)

from crisisformer import CrisisFormer

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data" / "sample_train.csv"
CONFIG = ROOT / "config.yaml"
OUT = ROOT / "outputs" / "phase3_eval_report.json"
LABEL_MAP = {0: "Non-Suicide", 1: "Suicide Risk"}


def main():
    print("=" * 60)
    print("PHASE 3 – Evaluation Report")
    print("=" * 60)

    df = pd.read_csv(DATA).dropna()
    model = CrisisFormer(str(CONFIG), num_labels=2)

    y_true, y_pred = [], []
    rows = []
    for _, row in df.iterrows():
        text = str(row["text"])
        true_id = int(row["label"])
        result = model.predict(text)
        pred_id = result["predicted_id"]
        y_true.append(true_id)
        y_pred.append(pred_id)
        rows.append({
            "text": text[:80],
            "true": LABEL_MAP[true_id],
            "pred": result["predicted_label"],
            "risk_prob": result["probabilities"].get("Suicide Risk", 0),
            "correct": true_id == pred_id,
        })

    acc = accuracy_score(y_true, y_pred)
    p, r, f1, _ = precision_recall_fscore_support(y_true, y_pred, average="weighted", zero_division=0)
    report = classification_report(y_true, y_pred, target_names=list(LABEL_MAP.values()), zero_division=0)
    cm = confusion_matrix(y_true, y_pred).tolist()

    payload = {
        "phase": 3,
        "evaluated_at": datetime.utcnow().isoformat() + "Z",
        "n_samples": len(df),
        "model_version": "phase2-finetuned" if model.fine_tuned else "base",
        "metrics": {
            "accuracy": float(acc),
            "precision": float(p),
            "recall": float(r),
            "f1": float(f1),
            "confusion_matrix": cm,
        },
        "classification_report": report,
        "samples": rows[:20],
        "ethics": "Research prototype only. Not for clinical use.",
    }

    OUT.parent.mkdir(parents=True, exist_ok=True)
    with open(OUT, "w") as f:
        json.dump(payload, f, indent=2)

    print(f"Accuracy : {acc:.4f}")
    print(f"Precision: {p:.4f}")
    print(f"Recall   : {r:.4f}")
    print(f"F1       : {f1:.4f}")
    print(report)
    print(f"\nReport saved: {OUT}")


if __name__ == "__main__":
    main()
