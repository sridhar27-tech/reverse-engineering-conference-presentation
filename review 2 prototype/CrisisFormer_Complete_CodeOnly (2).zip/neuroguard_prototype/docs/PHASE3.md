# Phase 3 – CrisisFormer (Near-complete prototype)

## Goals
- Full evaluation report with metrics
- Model compression path (ONNX export)
- Unified documentation for all phases
- Polished demo path for final review
- Target completion: **~85–90%**

## New in Phase 3
| Item | File / Location |
|------|-----------------|
| Evaluation script | `src/evaluate_phase3.py` |
| ONNX export script | `src/export_onnx_phase3.py` |
| Eval report output | `outputs/phase3_eval_report.json` |
| ONNX model (optional) | `models/crisisformer_onnx/` |
| Combined docs | `docs/PHASE3.md`, root README |

## Commands
```bash
# Evaluate
cd src
python evaluate_phase3.py

# Export ONNX (optional compression)
python export_onnx_phase3.py
```

## What is still future work
- Large real-world dataset fine-tuning
- Full clinical validation with experts
- Production MLOps (MLflow, CI/CD)
- Mobile TFLite packaging

## Ethics
Research prototype only. Not a medical device. Always requires human review.

## Self-Check Mode (added)

- You paste your own text / test query
- Model predicts + explains
- High-risk → red pulsing alert + browser sound
- You mark Correct / Incorrect → live accuracy
- Log saved to `outputs/self_check_log.json`
- Optional: Telegram message to **your** bot (not spoof SMS)

Privacy: only analyzes text you submit. No browser surveillance. No spoofed messages.
