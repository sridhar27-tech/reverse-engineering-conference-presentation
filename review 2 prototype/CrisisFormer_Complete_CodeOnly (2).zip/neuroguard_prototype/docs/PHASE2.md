# Phase 2 – CrisisFormer

## Goals (Review 2)

- Fine-tune DistilBERT on labeled suicide-risk text
- Save trained model into `models/crisisformer_phase2/`
- Report accuracy / precision / recall / F1
- Keep multi-layer explainability (Attention + SHAP-style + LIME)
- Improve live demo reliability (backend + frontend)

**Target completion:** ~70–75%

---

## What is new in Phase 2

| Item | Status |
|------|--------|
| Training script (`src/train_phase2.py`) | Done |
| Sample labeled dataset (`data/sample_train.csv`) | Done |
| Fine-tuned model save path | `models/crisisformer_phase2/` |
| Metrics (accuracy, F1, confusion matrix) | Saved in `metrics.json` |
| Auto-load fine-tuned weights in pipeline | Done |
| Multi-XAI (Attention + SHAP-style + LIME) | Done |
| Frontend / Backend | Compatible with Phase 2 model |

---

## How to run Phase 2 training

```bash
cd neuroguard_prototype
pip install -r requirements.txt

cd src
python train_phase2.py
```

After training you should see:

```
models/crisisformer_phase2/
  config.json
  model.safetensors  (or pytorch_model.bin)
  tokenizer files
  metrics.json
  label_map.json
```

---

## How to run the full system (after training)

**Terminal 1 – Backend**
```bash
cd backend
python -m uvicorn main:app --reload --port 8000
```

**Terminal 2 – Frontend**
```bash
cd frontend
python -m streamlit run app.py
```

The backend will automatically use the Phase-2 fine-tuned model if the folder exists.

---

## Using a real dataset later

Replace `data/sample_train.csv` with a larger labeled CSV that has columns:

```text
text,label
```

- `label = 0` → Non-Suicide  
- `label = 1` → Suicide Risk  

Then re-run `python train_phase2.py`.

Recommended public sources (for research only): SuicideWatch-style Reddit datasets on Kaggle (use only with proper ethics approval).

---

## Ethics reminder

This remains a **research prototype**.  
Not a medical device. Always require human review. Do not use for real clinical decisions.
