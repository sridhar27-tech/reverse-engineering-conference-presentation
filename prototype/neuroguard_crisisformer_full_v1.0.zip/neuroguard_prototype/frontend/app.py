"""
CrisisFormer Frontend
Run: python -m streamlit run app.py
"""

import streamlit as st
import requests
import plotly.express as px
import pandas as pd

st.set_page_config(page_title="CrisisFormer XAI", page_icon="🧠", layout="wide")

st.markdown("""
<style>
.main-title { font-size: 2.2rem; font-weight: 700; color: #1e3a5f; }
.risk-box { padding: 1.3rem; border-radius: 12px; text-align: center; font-size: 1.7rem; font-weight: bold; margin: 1rem 0; }
.disclaimer { background-color: #fff3cd; border-left: 6px solid #ffc107; padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem; }
</style>
""", unsafe_allow_html=True)

with st.sidebar:
    st.title("🧠 CrisisFormer")
    st.markdown("**DistilBERT + SHAP + LIME + Attention**")
    st.markdown("---")
    api_url = st.text_input("Backend API URL", value="http://localhost:8000")
    st.markdown("---")
    st.markdown("### Risk Levels")
    st.markdown("🟢 Non-Suicide  \n🔴 Suicide Risk")
    st.markdown("---")
    st.info("Research prototype only.\nInspired by CrisisFormer paper.")

st.markdown('<p class="main-title">CrisisFormer XAI</p>', unsafe_allow_html=True)
st.markdown("**Explainable Transformer-Based Suicide Risk Detection**")

st.markdown("""
<div class="disclaimer">
⚠️ <b>Disclaimer:</b> This is a research prototype only. Not a medical device. Always consult qualified mental health professionals.
</div>
""", unsafe_allow_html=True)

user_text = st.text_area("Enter text to analyze:", height=140, placeholder="Type or paste text here...")

if st.button("🔍 Analyze", type="primary", use_container_width=True):
    if not user_text.strip():
        st.warning("Please enter some text.")
    else:
        with st.spinner("Running DistilBERT + multi-layer explainability..."):
            try:
                response = requests.post(f"{api_url}/predict", json={"text": user_text, "explain": True}, timeout=60)
                if response.status_code != 200:
                    st.error(f"Backend error: {response.text}")
                else:
                    data = response.json()
                    label = data["predicted_label"]
                    bg, fg = ("#f8d7da", "#721c24") if "Suicide" in label else ("#d4edda", "#155724")
                    st.markdown(f'<div class="risk-box" style="background:{bg}; color:{fg}; border:2px solid {fg};">Predicted: {label}</div>', unsafe_allow_html=True)

                    if data.get("high_risk_alert"):
                        st.error("⚠️ High Risk Alert – Human review recommended")
                    if data.get("keyword_boost_applied"):
                        st.info("Clinical keyword boost was applied")

                    st.subheader("Risk Probability")
                    probs = data["probabilities"]
                    df = pd.DataFrame({"Class": list(probs.keys()), "Probability": list(probs.values())})
                    fig = px.bar(df, x="Class", y="Probability", color="Class",
                                 color_discrete_map={"Non-Suicide": "#28a745", "Suicide Risk": "#dc3545"},
                                 text=df["Probability"].apply(lambda x: f"{x:.1%}"), height=350)
                    fig.update_traces(textposition="outside")
                    fig.update_layout(showlegend=False, yaxis=dict(range=[0, 1.15]))
                    st.plotly_chart(fig, use_container_width=True)

                    st.subheader("Multi-Layer Explainability (CrisisFormer style)")
                    c1, c2, c3 = st.columns(3)

                    def show_expl(col, title, block):
                        with col:
                            st.markdown(f"**{title}**")
                            if block and block.get("top_tokens"):
                                tokens = [t["token"] for t in block["top_tokens"]]
                                scores = [t["score"] for t in block["top_tokens"]]
                                df_t = pd.DataFrame({"Token": tokens, "Score": scores})
                                fig_t = px.bar(df_t, x="Score", y="Token", orientation="h", color="Score",
                                               color_continuous_scale="Reds", height=320)
                                fig_t.update_layout(yaxis=dict(autorange="reversed"), showlegend=False)
                                st.plotly_chart(fig_t, use_container_width=True)
                                st.caption(block.get("method", ""))
                            else:
                                st.info("No data")

                    show_expl(c1, "Attention", data.get("attention"))
                    show_expl(c2, "SHAP-style", data.get("shap"))
                    show_expl(c3, "LIME-style", data.get("lime"))

                    st.subheader("Detailed Scores")
                    cols = st.columns(len(probs))
                    for i, (k, v) in enumerate(probs.items()):
                        cols[i].metric(k, f"{v:.1%}")

                    with st.expander("Full API Response"):
                        st.json(data)

            except requests.exceptions.ConnectionError:
                st.error("Cannot connect to backend. Start it with:\ncd backend\npython -m uvicorn main:app --reload --port 8000")
            except Exception as e:
                st.error(f"Error: {e}")

st.markdown("---")
st.caption("CrisisFormer XAI • DistilBERT + SHAP + LIME + Attention • Research Prototype")
