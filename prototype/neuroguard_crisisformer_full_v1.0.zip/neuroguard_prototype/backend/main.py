"""
CrisisFormer Backend API
DistilBERT + SHAP + LIME + Attention
Run: python -m uvicorn main:app --reload --port 8000
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Optional, List, Dict
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from pipeline import RiskPipeline

app = FastAPI(
    title="CrisisFormer API",
    description="Explainable Transformer-Based Suicide Risk Detection",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

CONFIG_PATH = Path(__file__).resolve().parent.parent / "config.yaml"
pipeline = RiskPipeline(str(CONFIG_PATH), num_labels=2)


class TextRequest(BaseModel):
    text: str = Field(..., min_length=1, max_length=2000)
    explain: bool = True


class TokenScore(BaseModel):
    token: str
    score: float


class ExplanationBlock(BaseModel):
    method: str
    top_tokens: List[TokenScore]


class PredictionResponse(BaseModel):
    predicted_label: str
    probabilities: Dict[str, float]
    keyword_boost_applied: bool = False
    attention: Optional[ExplanationBlock] = None
    shap: Optional[ExplanationBlock] = None
    lime: Optional[ExplanationBlock] = None
    high_risk_alert: bool
    disclaimer: str


@app.get("/")
def root():
    return {"message": "CrisisFormer Backend is running", "model": "DistilBERT + Multi-XAI", "status": "active"}


@app.get("/health")
def health():
    return {"status": "healthy"}


@app.post("/predict", response_model=PredictionResponse)
def predict(request: TextRequest):
    if not request.text.strip():
        raise HTTPException(status_code=400, detail="Text cannot be empty")

    try:
        result = pipeline.run(request.text, explain=request.explain)
        pred = result["prediction"]
        exp = result.get("explanation") or {}

        def to_block(block):
            if not block or not block.get("top_tokens"):
                return None
            return {
                "method": block.get("method", ""),
                "top_tokens": [
                    {"token": t[0], "score": round(float(t[1]), 4)}
                    for t in block["top_tokens"][:8]
                ]
            }

        return {
            "predicted_label": pred["predicted_label"],
            "probabilities": pred["probabilities"],
            "keyword_boost_applied": pred.get("keyword_boost_applied", False),
            "attention": to_block(exp.get("attention")),
            "shap": to_block(exp.get("shap")),
            "lime": to_block(exp.get("lime")),
            "high_risk_alert": result["flags"]["high_risk_alert"],
            "disclaimer": result["ethics"]["disclaimer"]
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
