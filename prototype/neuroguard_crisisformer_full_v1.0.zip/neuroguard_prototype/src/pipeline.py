"""
NeuroGuard / CrisisFormer Pipeline
Updated to use DistilBERT + multi-layer explainability (SHAP + LIME + Attention)
"""

from __future__ import annotations
from pathlib import Path
from typing import Dict, Optional
import json
from datetime import datetime
import yaml
import tempfile

from crisisformer import CrisisFormer


class RiskPipeline:
    def __init__(self, config_path: str = "config.yaml", num_labels: int = 2):
        self.config_path = config_path
        with open(config_path) as f:
            self.cfg = yaml.safe_load(f)

        self.model = CrisisFormer(config_path, num_labels=num_labels)

        project_root = Path(config_path).resolve().parent
        self.output_dir = project_root / self.cfg["paths"].get("output_dir", "outputs")
        try:
            self.output_dir.mkdir(parents=True, exist_ok=True)
        except PermissionError:
            self.output_dir = Path(tempfile.gettempdir()) / "neuroguard_outputs"
            self.output_dir.mkdir(parents=True, exist_ok=True)

    def run(self, text: str, explain: bool = True) -> Dict:
        if not text or not text.strip():
            return {"error": "Empty text provided"}

        prediction = self.model.predict(text)

        explanation = None
        if explain:
            full = self.model.full_explain(text)
            explanation = {
                "attention": full.get("attention"),
                "shap": full.get("shap"),
                "lime": full.get("lime"),
            }

        probs = prediction["probabilities"]
        risk_score = probs.get("Suicide Risk", probs.get("High Risk", 0))
        is_high = risk_score >= 0.55 or prediction.get("keyword_boost_applied", False)

        result = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "prediction": prediction,
            "explanation": explanation,
            "flags": {
                "high_risk_alert": is_high,
                "requires_human_review": True,
            },
            "ethics": {
                "disclaimer": "This is a research prototype only. Not a medical device. Do not use for real clinical decisions. Always involve qualified professionals.",
                "on_device": True,
                "consent_required": True,
            },
        }
        return result

    def save_report(self, result: Dict, filename: Optional[str] = None) -> Path:
        if filename is None:
            ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            filename = f"risk_report_{ts}.json"
        path = self.output_dir / filename
        with open(path, "w") as f:
            json.dump(result, f, indent=2)
        return path


def demo():
    print("=" * 60)
    print("CrisisFormer Pipeline Demo")
    print("=" * 60)
    cfg = Path(__file__).resolve().parent.parent / "config.yaml"
    pipe = RiskPipeline(str(cfg), num_labels=2)
    samples = [
        "I had a good day at work and I'm looking forward to the weekend.",
        "I feel completely hopeless and want to die. Nothing matters anymore.",
    ]
    for i, text in enumerate(samples, 1):
        print(f"\n--- Sample {i} ---")
        result = pipe.run(text)
        pred = result["prediction"]
        print(f"Predicted: {pred['predicted_label']}")
        print({k: round(v, 3) for k, v in pred["probabilities"].items()})
        print(f"High-risk: {result['flags']['high_risk_alert']}")


if __name__ == "__main__":
    demo()
