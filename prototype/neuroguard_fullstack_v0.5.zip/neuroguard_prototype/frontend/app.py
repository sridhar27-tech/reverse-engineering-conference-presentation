"""
NeuroGuard XAI - Frontend (Streamlit)
Run: streamlit run app.py
"""

import streamlit as st
import requests
import plotly.express as px
import pandas as pd

# --------------------------
# Page Config
# --------------------------
st.set_page_config(
    page_title="NeuroGuard XAI",
    page_icon="🧠",
    layout="wide"
)

# --------------------------
# Custom Style
# --------------------------
st.markdown("""
<style>
    .main-title { font-size: 2.3rem; font-weight: 700; color: #1e3a5f; }
    .risk-box {
        padding: 1.3rem; border-radius: 12px; text-align: center;
        font-size: 1.7rem; font-weight: bold; margin: 1rem 0;
    }
    .disclaimer {
        background-color: #fff3cd; border-left: 6px solid #ffc107;
        padding: 1rem; border-radius: 8px; margin-bottom: 1.5rem;
    }
</style>
""", unsafe_allow_html=True)

# --------------------------
# Sidebar
# --------------------------
with st.sidebar:
    st.title("🧠 NeuroGuard XAI")
    st.markdown("**Frontend + Backend Demo**")
    st.markdown("---")
    api_url = st.text_input("Backend API URL", value="http://localhost:8000")
    st.markdown("---")
    st.markdown("### Risk Levels")
    st.markdown("🟢 No Risk  \n🟡 Low Risk  \n🟠 Moderate Risk  \n🔴 High Risk")
    st.markdown("---")
    st.info("Research prototype only.\nNot for clinical use.")

# --------------------------
# Header
# --------------------------
st.markdown('<p class="main-title">NeuroGuard XAI</p>', unsafe_allow_html=True)
st.markdown("**Reverse Engineering BERT-based Suicide Risk Classification**")

st.markdown("""
<div class="disclaimer">
⚠️ <b>Disclaimer:</b> This is a research prototype only. Not a medical device. 
Always consult qualified mental health professionals.
</div>
""", unsafe_allow_html=True)

# --------------------------
# Input
# --------------------------
user_text = st.text_area(
    "Enter text to analyze:",
    height=140,
    placeholder="Type or paste text here..."
)

col1, col2 = st.columns([1, 3])
with col1:
    analyze = st.button("🔍 Analyze", type="primary", use_container_width=True)

# --------------------------
# Analysis
# --------------------------
if analyze:
    if not user_text.strip():
        st.warning("Please enter some text.")
    else:
        with st.spinner("Calling backend and analyzing..."):
            try:
                response = requests.post(
                    f"{api_url}/predict",
                    json={"text": user_text, "explain": True},
                    timeout=30
                )

                if response.status_code != 200:
                    st.error(f"Backend error: {response.text}")
                else:
                    data = response.json()

                    # Risk banner
                    label = data["predicted_label"]
                    colors = {
                        "No Risk": ("#d4edda", "#155724"),
                        "Low Risk": ("#fff3cd", "#856404"),
                        "Moderate Risk": ("#ffe0b2", "#e65100"),
                        "High Risk": ("#f8d7da", "#721c24"),
                    }
                    bg, fg = colors.get(label, ("#e2e3e5", "#333"))

                    st.markdown(f"""
                    <div class="risk-box" style="background:{bg}; color:{fg}; border:2px solid {fg};">
                        Predicted Risk: {label}
                    </div>
                    """, unsafe_allow_html=True)

                    if data.get("high_risk_alert"):
                        st.error("⚠️ High Risk Alert – Human review recommended")

                    # Charts
                    left, right = st.columns(2)

                    with left:
                        st.subheader("Risk Probability")
                        probs = data["probabilities"]
                        df = pd.DataFrame({
                            "Risk Level": list(probs.keys()),
                            "Probability": list(probs.values())
                        })
                        fig = px.bar(
                            df, x="Risk Level", y="Probability",
                            color="Risk Level",
                            color_discrete_map={
                                "No Risk": "#28a745",
                                "Low Risk": "#ffc107",
                                "Moderate Risk": "#fd7e14",
                                "High Risk": "#dc3545"
                            },
                            text=df["Probability"].apply(lambda x: f"{x:.1%}"),
                            height=380
                        )
                        fig.update_traces(textposition="outside")
                        fig.update_layout(showlegend=False, yaxis=dict(range=[0, 1.15]))
                        st.plotly_chart(fig, use_container_width=True)

                    with right:
                        st.subheader("Important Tokens")
                        if data.get("top_tokens"):
                            tokens = [t["token"] for t in data["top_tokens"]]
                            scores = [t["score"] for t in data["top_tokens"]]
                            df_t = pd.DataFrame({"Token": tokens, "Score": scores})
                            fig2 = px.bar(
                                df_t, x="Score", y="Token", orientation="h",
                                color="Score", color_continuous_scale="Reds",
                                height=380
                            )
                            fig2.update_layout(yaxis=dict(autorange="reversed"), showlegend=False)
                            st.plotly_chart(fig2, use_container_width=True)
                        else:
                            st.info("No token data")

                    # Metrics
                    st.subheader("Detailed Scores")
                    cols = st.columns(4)
                    for i, (k, v) in enumerate(data["probabilities"].items()):
                        cols[i].metric(k, f"{v:.1%}")

                    with st.expander("Full API Response"):
                        st.json(data)

            except requests.exceptions.ConnectionError:
                st.error("Cannot connect to backend. Please start the backend first:\n\n`cd backend && uvicorn main:app --reload`")
            except Exception as e:
                st.error(f"Error: {e}")

st.markdown("---")
st.caption("NeuroGuard XAI • Frontend + Backend • Research Prototype")