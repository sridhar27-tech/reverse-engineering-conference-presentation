# How to Run Frontend + Backend

## 1. Install Requirements
```bash
pip install -r requirements.txt
pip install streamlit plotly requests uvicorn fastapi
```

## 2. Start Backend (Terminal 1)
```bash
cd backend
uvicorn main:app --reload --port 8000
```
Backend will run at: http://localhost:8000
API Docs: http://localhost:8000/docs

## 3. Start Frontend (Terminal 2)
```bash
cd frontend
streamlit run app.py
```
Frontend will open at: http://localhost:8501

## 4. Use the System
- Type text in the frontend
- Click Analyze
- See risk level + bar charts

## Note
Keep both terminals open while using the system.