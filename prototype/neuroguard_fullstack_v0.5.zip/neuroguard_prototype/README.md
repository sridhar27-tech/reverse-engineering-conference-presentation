# NeuroGuard-XAI Prototype (≈ 30–40 %)

**Reverse Engineering BERT-based Suicide Risk Classifiers for Interpretable, Cross-Platform Mental Health Deployment**

> Research / academic prototype only.  
> **Not a medical device. Not for clinical use.**

---

## What this prototype includes

| Component                    | Status      | Notes |
|-----------------------------|-------------|-------|
| Project structure + config  | ✅ Done     | `config.yaml` |
| BERT backbone + classifier  | ✅ Done     | `src/model.py` (untrained head for demo) |
| Inference pipeline          | ✅ Done     | `src/pipeline.py` |
| CLI entry point             | ✅ Done     | `src/main.py` |
| Simple attention-based XAI  | ✅ Done     | Basic reverse-engineering signal |
| Ethical disclaimers         | ✅ Done     | Always shown |
| Sample data & reports       | ✅ Done     | `data/` + `outputs/` |
| Full fine-tuning            | ❌ Later    | Needs labeled dataset |
| SHAP / TCAV / probing       | ❌ Later    | Scaffold only |
| Model compression (ONNX/TFLite) | ❌ Later | Planned |
| Real MLOps (MLflow, DVC)    | ❌ Later    | Structure ready |
| Mobile / on-device packaging | ❌ Later    | |

---

## Quick Start

```bash
# 1. Create virtual environment (recommended)
python -m venv venv
source venv/bin/activate          # Linux / macOS
# venv\Scripts\activate           # Windows

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run demo
cd src
python main.py --demo

# 4. Analyze your own text
python main.py --text "I feel completely hopeless and don't see a way forward."

# 5. Save JSON report
python main.py --text "..." --save
```

---

## Project Layout

```
neuroguard_prototype/
├── config.yaml              # All settings
├── requirements.txt
├── README.md
├── src/
│   ├── model.py             # BERT + classifier + simple explain
│   ├── pipeline.py          # predict → explain → report
│   └── main.py              # CLI
├── data/                    # sample texts
├── models/                  # (future checkpoints)
├── outputs/                 # generated reports
├── notebooks/               # (future experiments)
└── docs/                    # (future paper notes)
```

---

## Ethical & Safety Notes (Important)

1. This is a **technical demonstration** of reverse engineering and explainability.
2. The classification head is **not fine-tuned** on real clinical data in this prototype.
3. Always keep a **human-in-the-loop**.
4. Only process text the user has **explicitly consented** to analyze.
5. Do **not** use this for surveillance, hidden monitoring, or real-time search-history tracking without consent.
6. If you or someone else is in crisis, contact local emergency services or a suicide prevention helpline immediately  
   (e.g. https://www.iasp.info/suicidalthoughts/ or local numbers such as 988 in the US).

---

## Next Steps to reach ~70–100 %

- Fine-tune on public datasets (UMD Suicidality, CLPsych, etc.) with proper ethics approval.
- Add full SHAP + attention visualization + probing experiments.
- Integrate MLflow / DVC for experiment tracking.
- Export to ONNX / TFLite / Core ML for on-device inference.
- Build a minimal FastAPI or Streamlit UI with clear consent screens.
- Bias & fairness audit.
- Clinical validation study (with domain experts).

---

## License & Disclaimer

MIT (or as preferred by your college).  
**This software is provided for research and educational purposes only.**  
The authors accept no liability for any clinical or real-world use.

---

*Prototype created for the reverse-engineering conference project – Dr. Mahalingam College of Engineering & Technology.*