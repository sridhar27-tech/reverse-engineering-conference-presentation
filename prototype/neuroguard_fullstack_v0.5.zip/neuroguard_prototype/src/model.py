"""
NeuroGuard XAI - Model Module (Prototype ~30-40%)
BERT-based risk classifier with basic reverse-engineering hooks.
"""

from __future__ import annotations
import torch
from torch import nn
from transformers import AutoModel, AutoTokenizer, AutoConfig
from typing import Dict, List, Tuple, Optional
import yaml
from pathlib import Path


class RiskClassifier(nn.Module):
    """
    Simple BERT + classification head for 4-class suicide risk.
    Designed so we can later reverse-engineer attention & embeddings.
    """

    def __init__(self, model_name: str = "bert-base-uncased", num_labels: int = 4):
        super().__init__()
        # Force eager attention so output_attentions works reliably
        self.config = AutoConfig.from_pretrained(model_name)
        self.config.attn_implementation = "eager"
        self.bert = AutoModel.from_pretrained(
            model_name, config=self.config, attn_implementation="eager"
        )
        self.dropout = nn.Dropout(0.1)
        self.classifier = nn.Linear(self.config.hidden_size, num_labels)

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        return_attentions: bool = False,
    ) -> Dict[str, torch.Tensor]:
        outputs = self.bert(
            input_ids=input_ids,
            attention_mask=attention_mask,
            output_attentions=return_attentions,
            return_dict=True,
        )
        pooled = outputs.last_hidden_state[:, 0]  # [CLS]
        pooled = self.dropout(pooled)
        logits = self.classifier(pooled)

        result = {"logits": logits, "pooled": pooled}
        if return_attentions and outputs.attentions is not None:
            result["attentions"] = outputs.attentions  # tuple of layers
        return result


class NeuroGuardModel:
    """
    High-level wrapper used by the pipeline.
    Loads tokenizer + model and provides predict + explain interface.
    """

    def __init__(self, config_path: str = "config.yaml"):
        with open(config_path, "r") as f:
            self.cfg = yaml.safe_load(f)

        self.model_name = self.cfg["model"]["name"]
        self.num_labels = self.cfg["model"]["num_labels"]
        self.max_length = self.cfg["model"]["max_length"]
        self.device = torch.device(self.cfg["model"]["device"])
        self.label_map = {int(k): v for k, v in self.cfg["labels"].items()}

        print(f"[NeuroGuard] Loading tokenizer & model: {self.model_name}")
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
        self.model = RiskClassifier(self.model_name, self.num_labels)
        self.model.to(self.device)
        self.model.eval()

        # For prototype we keep random/untrained head.
        # In full project this would be a fine-tuned checkpoint.
        print("[NeuroGuard] Prototype model ready (untrained head – demo only)")

    def encode(self, texts: List[str]) -> Dict[str, torch.Tensor]:
        encoded = self.tokenizer(
            texts,
            padding=True,
            truncation=True,
            max_length=self.max_length,
            return_tensors="pt",
        )
        return {k: v.to(self.device) for k, v in encoded.items()}

    @torch.no_grad()
    def predict(self, text: str) -> Dict:
        """Return risk label + probabilities."""
        inputs = self.encode([text])
        outputs = self.model(
            input_ids=inputs["input_ids"],
            attention_mask=inputs["attention_mask"],
            return_attentions=False,
        )
        logits = outputs["logits"]
        probs = torch.softmax(logits, dim=-1)[0].cpu().numpy()

        pred_id = int(probs.argmax())
        return {
            "text": text,
            "predicted_label": self.label_map[pred_id],
            "predicted_id": pred_id,
            "probabilities": {
                self.label_map[i]: float(probs[i]) for i in range(self.num_labels)
            },
            "disclaimer": "PROTOTYPE ONLY – Not for clinical use. Human review required.",
        }

    @torch.no_grad()
    def explain_simple(self, text: str, top_k: int = 8) -> Dict:
        """
        Very basic reverse-engineering step:
        Use average attention from last layer to the [CLS] token
        as a crude importance score for tokens.
        """
        inputs = self.encode([text])
        outputs = self.model(
            input_ids=inputs["input_ids"],
            attention_mask=inputs["attention_mask"],
            return_attentions=True,
        )

        # attentions: tuple (num_layers, batch, heads, seq, seq)
        # take last layer, average over heads, look at attention TO [CLS] (position 0)
        last_attn = outputs["attentions"][-1]  # (1, heads, seq, seq)
        avg_attn = last_attn[0].mean(dim=0)    # (seq, seq)
        cls_attn = avg_attn[0]                 # attention from all tokens to CLS? or vice-versa
        # Better: average attention that [CLS] pays to other tokens
        cls_to_tokens = avg_attn[:, 0] if avg_attn.shape[0] > 1 else avg_attn[0]

        tokens = self.tokenizer.convert_ids_to_tokens(inputs["input_ids"][0])
        scores = cls_to_tokens.cpu().numpy()

        # filter special tokens
        ranked = []
        for tok, sc in zip(tokens, scores):
            if tok in ("[CLS]", "[SEP]", "[PAD]"):
                continue
            ranked.append((tok.replace("##", ""), float(sc)))

        ranked = sorted(ranked, key=lambda x: x[1], reverse=True)[:top_k]

        return {
            "text": text,
            "top_tokens": ranked,
            "method": "last-layer average attention (prototype reverse-engineering)",
            "note": "This is a simplified explainability signal. Full project uses SHAP + TCAV + probing.",
        }


if __name__ == "__main__":
    # quick self-test
    m = NeuroGuardModel("config.yaml")
    sample = "I feel completely hopeless and don't see any point in continuing."
    print(m.predict(sample))
    print(m.explain_simple(sample))