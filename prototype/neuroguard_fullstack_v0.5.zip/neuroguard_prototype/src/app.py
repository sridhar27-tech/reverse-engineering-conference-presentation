"""
NeuroGuard XAI - Live Interactive Demo with Charts
Run with: streamlit run app.py
"""

import streamlit as st
import sys
from pathlib import Path
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd

# Add current directory so we can import pipeline
sys.path.insert(0, str(Path(__file__).parent))

from pipeline import RiskPipeline

# --------------------------
# Page Config
# --------------------------
st.set_page_config(
    page_title="NeuroGuard XAI",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded"
)

# --------------------------
# Custom CSS
# --------------------------
st.markdown("""
<style>
    .main-title {
        font-size: 2.4rem;
        font-weight: 700;
        color: #1e3a5f;
    }
    .subtitle {
        font-size: 1.1rem;
        color: #555;
        margin-bottom: 1.5rem;
    }
    .risk-box {
        padding: 1.2rem;
        border-radius: 12px;
        text-align: center;
        font-size: 1.6rem;
        font-weight: bold;
        margin: 1rem 0;
    }
    .disclaimer {
        background-color: #fff3cd;
        border-left: 5px solid #ffc107;
        padding: 1rem;
        border-radius: 6px;
        font-size: 0.95rem;
    }
</style>
""", unsafe_allow_html=True)

# --------------------------
# Load Pipeline (cached)
# --------------------------
@st.cache_resource
def load_pipeline():
    config_path = Path(__file__).resolve().parent.parent / "config.yaml"
    return RiskPipeline(str(config_path))

pipe = load_pipeline()

# --------------------------
# Sidebar
# --------------------------
with st.sidebar:
    st.title("🧠 NeuroGuard XAI")
    st.markdown("**Reverse Engineering + Explainable Risk Detection**")
    st.markdown("---")
    st.markdown("### How to use")
    st.markdown("""
    1. Type or paste text in the box  
    2. Click **Analyze**  
    3. See risk level + charts  
    """)
    st.markdown("---")
    st.markdown("### Risk Levels")
    st.markdown("""
    - 🟢 **No Risk**  
    - 🟡 **Low Risk**  
    - 🟠 **Moderate Risk**  
    - 🔴 **High Risk**  
    """)
    st.markdown("---")
    st.info("This is a **research prototype** only.\nNot for clinical use.")

# --------------------------
# Main Area
# --------------------------
st.markdown('<p class="main-title">NeuroGuard XAI Live Demo</p>', unsafe_allow_html=True)
st.markdown('<p class="subtitle">BERT-based Suicide Risk Classification with Explainability</p>', unsafe_allow_html=True)

st.markdown("""
<div class="disclaimer">
⚠️ <b>Important:</b> This is a technical research prototype only. 
It is <b>not</b> a medical device. Always involve qualified mental health professionals.
If you or someone else is in crisis, please contact local emergency services or a helpline immediately.
</div>
""", unsafe_allow_html=True)

st.markdown("---")

# Text input
user_text = st.text_area(
    "Enter text to analyze (live input):",
    height=150,
    placeholder="Type or paste any text here...\nExample: I feel completely hopeless and don't see a way forward."
)

col1, col2, col3 = st.columns([1, 1, 2])
with col1:
    analyze_btn = st.button("🔍 Analyze Text", type="primary", use_container_width=True)
with col2:
    clear_btn = st.button("Clear", use_container_width=True)

if clear_btn:
    st.rerun()

# --------------------------
# Analysis
# --------------------------
if analyze_btn:
    if not user_text.strip():
        st.warning("Please enter some text first.")
    else:
        with st.spinner("Analyzing with BERT + generating explanations..."):
            result = pipe.run(user_text, explain=True)

        pred = result["prediction"]
        explanation = result.get("explanation")
        flags = result["flags"]

        # ----- Risk Level Banner -----
        label = pred["predicted_label"]
        color_map = {
            "No Risk": ("#d4edda", "#155724"),
            "Low Risk": ("#fff3cd", "#856404"),
            "Moderate Risk": ("#ffe0b2", "#e65100"),
            "High Risk": ("#f8d7da", "#721c24"),
        }
        bg, fg = color_map.get(label, ("#e2e3e5", "#383d41"))

        st.markdown(f"""
        <div class="risk-box" style="background-color:{bg}; color:{fg}; border: 2px solid {fg};">
            Predicted Risk Level: {label}
        </div>
        """, unsafe_allow_html=True)

        if flags["high_risk_alert"]:
            st.error("⚠️ High Risk flag triggered — Human review strongly recommended.")

        # ----- Two columns for charts -----
        left, right = st.columns(2)

        # 1. Probability Bar Chart
        with left:
            st.subheader("Risk Probability Distribution")
            probs = pred["probabilities"]
            df_prob = pd.DataFrame({
                "Risk Level": list(probs.keys()),
                "Probability": list(probs.values())
            })

            fig_bar = px.bar(
                df_prob,
                x="Risk Level",
                y="Probability",
                color="Risk Level",
                color_discrete_map={
                    "No Risk": "#28a745",
                    "Low Risk": "#ffc107",
                    "Moderate Risk": "#fd7e14",
                    "High Risk": "#dc3545"
                },
                text=df_prob["Probability"].apply(lambda x: f"{x:.1%}"),
                height=400
            )
            fig_bar.update_traces(textposition="outside")
            fig_bar.update_layout(
                yaxis_title="Probability",
                xaxis_title="",
                showlegend=False,
                yaxis=dict(range=[0, 1.1]),
                margin=dict(t=30, b=30)
            )
            st.plotly_chart(fig_bar, use_container_width=True)

        # 2. Token Importance Chart
        with right:
            st.subheader("Top Important Tokens (Attention)")
            if explanation and explanation.get("top_tokens"):
                tokens = [t[0] for t in explanation["top_tokens"][:8]]
                scores = [t[1] for t in explanation["top_tokens"][:8]]

                df_tok = pd.DataFrame({"Token": tokens, "Importance": scores})

                fig_tok = px.bar(
                    df_tok,
                    x="Importance",
                    y="Token",
                    orientation="h",
                    color="Importance",
                    color_continuous_scale="Reds",
                    height=400
                )
                fig_tok.update_layout(
                    yaxis=dict(autorange="reversed"),
                    xaxis_title="Attention Score",
                    yaxis_title="",
                    showlegend=False,
                    margin=dict(t=30, b=30)
                )
                st.plotly_chart(fig_tok, use_container_width=True)
            else:
                st.info("No token explanation available.")

        # ----- Detailed numbers -----
        st.subheader("Detailed Probabilities")
        cols = st.columns(4)
        for i, (label_name, prob) in enumerate(probs.items()):
            cols[i].metric(label_name, f"{prob:.1%}")

        # ----- Raw JSON (optional) -----
        with st.expander("View full JSON result"):
            st.json(result)

        st.markdown("---")
        st.caption("NeuroGuard XAI Prototype • Research use only • Always require human review")

# --------------------------
# Footer
# --------------------------
st.markdown("---")
st.markdown("""
<small>
Built as a reverse-engineering + explainable AI prototype for suicide risk classification research.<br>
Model: BERT-base (untrained classification head in this demo version).
</small>
""", unsafe_allow_html=True)