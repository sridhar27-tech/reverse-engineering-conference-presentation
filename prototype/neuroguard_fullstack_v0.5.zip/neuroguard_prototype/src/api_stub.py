"""
Optional FastAPI stub (not required for core prototype).
Run with: uvicorn api_stub:app --reload
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Optional
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from pipeline import RiskPipeline

app = FastAPI(
    title="NeuroGuard XAI Prototype API",
    description="Research-only risk classification endpoint. Not for clinical use.",
    version="0.3.0",
)

pipe = RiskPipeline("../config.yaml")


class TextRequest(BaseModel):
    text: str = Field(..., min_length=1, max_length=2000)
    explain: bool = True


@app.get("/")
def root():
    return {
        "message": "NeuroGuard XAI Prototype",
        "status": "research-only",
        "disclaimer": "Not a medical device. Human review required.",
    }


@app.post("/predict")
def predict(req: TextRequest):
    if not req.text.strip():
        raise HTTPException(400, "Empty text")
    result = pipe.run(req.text, explain=req.explain)
    return result