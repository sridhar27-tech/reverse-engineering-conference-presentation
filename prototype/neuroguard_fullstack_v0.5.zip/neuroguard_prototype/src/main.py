"""
NeuroGuard XAI – Main entry point (Prototype 30-40%)
CLI interface for the reverse-engineering risk prediction system.
"""

import argparse
import json
import sys
from pathlib import Path

# allow running from project root
sys.path.insert(0, str(Path(__file__).parent))

from pipeline import RiskPipeline


DISCLAIMER = """
================================================================
  NEUROGUARD XAI PROTOTYPE – RESEARCH USE ONLY
================================================================
  This system is a technical demonstration of reverse engineering
  and explainable AI for suicide-risk text classification.

  • NOT a medical device
  • NOT for clinical decision making
  • Always require human professional review
  • Process only data the user has explicitly consented to share
================================================================
"""


def main():
    parser = argparse.ArgumentParser(
        description="NeuroGuard XAI – BERT Risk Classification Prototype"
    )
    parser.add_argument(
        "--text", "-t", type=str, help="Input text to analyze"
    )
    parser.add_argument(
        "--file", "-f", type=str, help="Path to a text file (one sample)"
    )
    parser.add_argument(
        "--demo", action="store_true", help="Run built-in demo samples"
    )
    parser.add_argument(
        "--no-explain", action="store_true", help="Skip explainability step"
    )
    parser.add_argument(
        "--config", default="config.yaml", help="Path to config.yaml"
    )
    parser.add_argument(
        "--save", action="store_true", help="Save JSON report to outputs/"
    )
    args = parser.parse_args()

    print(DISCLAIMER)

    # Resolve config path relative to project root
    config_path = Path(args.config)
    if not config_path.exists():
        # try relative to this file
        config_path = Path(__file__).parent.parent / "config.yaml"
    if not config_path.exists():
        print(f"[ERROR] Config not found: {args.config}")
        sys.exit(1)

    pipe = RiskPipeline(str(config_path))

    if args.demo:
        from pipeline import demo
        demo()
        return

    text = None
    if args.text:
        text = args.text
    elif args.file:
        text = Path(args.file).read_text(encoding="utf-8").strip()
    else:
        print("Enter text to analyze (end with Ctrl+D / Ctrl+Z):")
        text = sys.stdin.read().strip()

    if not text:
        print("No text provided.")
        sys.exit(1)

    result = pipe.run(text, explain=not args.no_explain)

    print("\n=== Prediction ===")
    pred = result["prediction"]
    print(f"Label : {pred['predicted_label']}")
    print("Probabilities:")
    for k, v in pred["probabilities"].items():
        bar = "█" * int(v * 20)
        print(f"  {k:15s} {v:.3f}  {bar}")

    if result.get("explanation"):
        print("\n=== Simple Reverse-Engineering Signal (Attention) ===")
        for tok, score in result["explanation"]["top_tokens"]:
            print(f"  {tok:20s} {score:.4f}")

    print("\n=== Flags ===")
    print(f"High-risk alert     : {result['flags']['high_risk_alert']}")
    print(f"Requires human review: {result['flags']['requires_human_review']}")

    print("\n" + result["ethics"]["disclaimer"])

    if args.save:
        path = pipe.save_report(result)
        print(f"\nReport saved → {path}")


if __name__ == "__main__":
    main()