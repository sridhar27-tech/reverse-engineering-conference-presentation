# NeuroGuard-XAI Prototype Architecture (30–40 %)

```
User text (consented)
        │
        ▼
┌───────────────────┐
│  Tokenizer (BERT) │
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│  BERT Encoder     │  ← reverse-engineering target
│  (attention layers)│
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│ Classification    │  ← 4-class head (No / Low / Moderate / High)
│ Head              │
└─────────┬─────────┘
          │
          ▼
┌───────────────────┐
│ Simple XAI        │  ← last-layer attention → token importance
│ (prototype)       │
└─────────┬─────────┘
          │
          ▼
   JSON report + flags
   (always requires human review)
```

## Planned full reverse-engineering stack (later)

1. SHAP / KernelSHAP token attributions
2. Multi-head attention visualization (BertViz style)
3. Layer probing for clinical concepts (C-SSRS aligned)
4. TCAV concept testing
5. Bias & subgroup analysis
6. Adversarial robustness checks

## Deployment targets (future)

- ONNX Runtime (Linux / Windows / macOS)
- TFLite (Android)
- Core ML (iOS)
- Always prefer on-device inference for privacy.