"""
NeuroGuard XAI - Inference Pipeline (Prototype)
Simple MLOps-style pipeline: preprocess → predict → explain → report
"""

from __future__ import annotations
from pathlib import Path
from typing import Dict, List, Optional
import json
from datetime import datetime
import yaml

from model import NeuroGuardModel


class RiskPipeline:
    def __init__(self, config_path: str = "config.yaml"):
        self.config_path = config_path
        with open(config_path) as f:
            self.cfg = yaml.safe_load(f)

        self.model = NeuroGuardModel(config_path)

        # Always create outputs folder inside the project root
        project_root = Path(config_path).resolve().parent
        self.output_dir = project_root / self.cfg["paths"].get("output_dir", "outputs")
        try:
            self.output_dir.mkdir(parents=True, exist_ok=True)
        except PermissionError:
            # Fallback to a temp folder if permission denied
            import tempfile
            self.output_dir = Path(tempfile.gettempdir()) / "neuroguard_outputs"
            self.output_dir.mkdir(parents=True, exist_ok=True)

    def run(self, text: str, explain: bool = True) -> Dict:
        """Full pipeline step for one text sample."""
        if not text or not text.strip():
            return {"error": "Empty text provided"}

        # 1. Prediction
        prediction = self.model.predict(text)

        # 2. Optional explainability (reverse-engineering hook)
        explanation = None
        if explain:
            top_k = self.cfg["explainability"].get("top_k_tokens", 8)
            explanation = self.model.explain_simple(text, top_k=top_k)

        # 3. Risk flag (prototype logic)
        high_threshold = self.cfg["inference"].get("threshold_high", 0.65)
        is_high = (
            prediction["predicted_id"] == 3
            or prediction["probabilities"].get("High Risk", 0) >= high_threshold
        )

        result = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "prediction": prediction,
            "explanation": explanation,
            "flags": {
                "high_risk_alert": is_high,
                "requires_human_review": True,  # always in prototype
            },
            "ethics": {
                "disclaimer": "This is a research prototype only. Not a medical device. "
                              "Do not use for real clinical decisions. Always involve qualified professionals.",
                "on_device": True,
                "consent_required": True,
            },
        }
        return result

    def save_report(self, result: Dict, filename: Optional[str] = None) -> Path:
        if filename is None:
            ts = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            filename = f"risk_report_{ts}.json"
        path = self.output_dir / filename
        with open(path, "w") as f:
            json.dump(result, f, indent=2)
        return path


def demo():
    print("=" * 60)
    print("NeuroGuard XAI Prototype – Risk Pipeline Demo")
    print("=" * 60)

    from pathlib import Path
    cfg = Path(__file__).resolve().parent.parent / "config.yaml"
    pipe = RiskPipeline(str(cfg))

    samples = [
        "I had a good day at work and I'm looking forward to the weekend.",
        "I've been feeling really down and overwhelmed lately, nothing seems to help.",
        "I don't want to be here anymore. Everything feels pointless and I can't go on.",
    ]

    for i, text in enumerate(samples, 1):
        print(f"\n--- Sample {i} ---")
        print(f"Input: {text[:80]}...")
        result = pipe.run(text)
        pred = result["prediction"]
        print(f"Predicted: {pred['predicted_label']}")
        print("Probabilities:")
        for label, p in pred["probabilities"].items():
            print(f"  {label:15s}: {p:.3f}")
        if result["explanation"]:
            print("Top tokens (attention-based importance):")
            for tok, score in result["explanation"]["top_tokens"][:5]:
                print(f"  {tok:15s}: {score:.4f}")
        print(f"High-risk flag: {result['flags']['high_risk_alert']}")
        print(result["ethics"]["disclaimer"])

    print("\n[Demo finished] Reports can be saved with pipe.save_report(result)")


if __name__ == "__main__":
    demo()