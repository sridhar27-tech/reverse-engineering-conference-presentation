"""
CrisisFormer-style Model (inspired by the paper)
DistilBERT + Multi-layer Explainability (Attention + SHAP + LIME)
"""

from __future__ import annotations
import torch
from torch import nn
from transformers import AutoModel, AutoTokenizer, AutoConfig, DistilBertModel
from typing import Dict, List, Optional, Tuple
import numpy as np
import yaml
from pathlib import Path

# Optional heavy explainers
try:
    import shap
    HAS_SHAP = True
except ImportError:
    HAS_SHAP = False

try:
    from lime.lime_text import LimeTextExplainer
    HAS_LIME = True
except ImportError:
    HAS_LIME = False


class CrisisFormerClassifier(nn.Module):
    """
    DistilBERT + classification head
    Closely follows the paper's CrisisFormer backbone.
    """

    def __init__(self, model_name: str = "distilbert-base-uncased", num_labels: int = 2):
        super().__init__()
        self.config = AutoConfig.from_pretrained(model_name)
        self.config.attn_implementation = "eager"
        self.distilbert = AutoModel.from_pretrained(
            model_name, config=self.config, attn_implementation="eager"
        )
        self.dropout = nn.Dropout(0.2)
        self.classifier = nn.Linear(self.config.hidden_size, num_labels)

    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: torch.Tensor,
        return_attentions: bool = False,
    ) -> Dict[str, torch.Tensor]:
        outputs = self.distilbert(
            input_ids=input_ids,
            attention_mask=attention_mask,
            output_attentions=return_attentions,
            return_dict=True,
        )
        # DistilBERT uses last_hidden_state; take [CLS] equivalent (first token)
        pooled = outputs.last_hidden_state[:, 0]
        pooled = self.dropout(pooled)
        logits = self.classifier(pooled)

        result = {"logits": logits, "pooled": pooled}
        if return_attentions and outputs.attentions is not None:
            result["attentions"] = outputs.attentions
        return result


class CrisisFormer:
    """
    High-level wrapper inspired by the paper.
    Provides prediction + multi-layer explainability.
    """

    def __init__(self, config_path: str = "config.yaml", num_labels: int = 2):
        with open(config_path, "r") as f:
            self.cfg = yaml.safe_load(f)

        self.model_name = "distilbert-base-uncased"
        self.num_labels = num_labels
        self.max_length = self.cfg["model"].get("max_length", 128)
        self.device = torch.device(self.cfg["model"].get("device", "cpu"))

        # Binary labels for CrisisFormer style
        if num_labels == 2:
            self.label_map = {0: "Non-Suicide", 1: "Suicide Risk"}
        else:
            self.label_map = {int(k): v for k, v in self.cfg["labels"].items()}

        print(f"[CrisisFormer] Loading DistilBERT: {self.model_name}")
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
        self.model = CrisisFormerClassifier(self.model_name, num_labels)
        self.model.to(self.device)
        self.model.eval()
        print("[CrisisFormer] Model ready (prototype – head not fully fine-tuned yet)")

        # Simple clinical keyword boost (helps until full fine-tuning)
        self.high_risk_keywords = {
            "die", "suicide", "kill", "hopeless", "end it", "no reason",
            "disappear", "worthless", "can't go on", "end my life",
            "want to die", "better off dead", "no future"
        }

    def encode(self, texts: List[str]) -> Dict[str, torch.Tensor]:
        encoded = self.tokenizer(
            texts,
            padding=True,
            truncation=True,
            max_length=self.max_length,
            return_tensors="pt",
        )
        return {k: v.to(self.device) for k, v in encoded.items()}

    def _keyword_boost(self, text: str) -> float:
        text_lower = text.lower()
        hits = sum(1 for kw in self.high_risk_keywords if kw in text_lower)
        return min(0.35, hits * 0.12)  # max +0.35 boost

    @torch.no_grad()
    def predict(self, text: str) -> Dict:
        inputs = self.encode([text])
        outputs = self.model(
            input_ids=inputs["input_ids"],
            attention_mask=inputs["attention_mask"],
            return_attentions=False,
        )
        logits = outputs["logits"]
        probs = torch.softmax(logits, dim=-1)[0].cpu().numpy()

        # Apply keyword boost for High Risk / Suicide class
        boost = self._keyword_boost(text)
        if self.num_labels == 2:
            probs[1] = min(0.98, probs[1] + boost)
            probs[0] = 1.0 - probs[1]
        else:
            # 4-class: boost High Risk (index 3)
            probs[3] = min(0.95, probs[3] + boost)
            probs = probs / probs.sum()

        pred_id = int(probs.argmax())
        return {
            "text": text,
            "predicted_label": self.label_map[pred_id],
            "predicted_id": pred_id,
            "probabilities": {
                self.label_map[i]: float(probs[i]) for i in range(self.num_labels)
            },
            "keyword_boost_applied": boost > 0,
            "disclaimer": "PROTOTYPE – Research only. Not for clinical use.",
        }

    @torch.no_grad()
    def explain_attention(self, text: str, top_k: int = 10) -> Dict:
        """Native attention visualization (paper method 3)"""
        inputs = self.encode([text])
        outputs = self.model(
            input_ids=inputs["input_ids"],
            attention_mask=inputs["attention_mask"],
            return_attentions=True,
        )
        if "attentions" not in outputs:
            return {"top_tokens": [], "method": "attention (unavailable)"}

        last_attn = outputs["attentions"][-1]  # (1, heads, seq, seq)
        avg_attn = last_attn[0].mean(dim=0)   # average over heads
        cls_to_tokens = avg_attn[:, 0]

        tokens = self.tokenizer.convert_ids_to_tokens(inputs["input_ids"][0])
        ranked = []
        for tok, sc in zip(tokens, cls_to_tokens.cpu().numpy()):
            if tok in ("[CLS]", "[SEP]", "[PAD]", "<s>", "</s>"):
                continue
            clean = tok.replace("##", "")
            ranked.append((clean, float(sc)))

        ranked = sorted(ranked, key=lambda x: x[1], reverse=True)[:top_k]
        return {
            "top_tokens": ranked,
            "method": "DistilBERT last-layer attention (CrisisFormer style)",
        }

    def explain_shap(self, text: str, top_k: int = 8) -> Dict:
        """SHAP token importance (paper method 1) – simplified for prototype"""
        if not HAS_SHAP:
            return {"top_tokens": [], "method": "SHAP (library not installed)"}

        # For prototype we use a lightweight approximation
        # Full KernelSHAP on transformers is slow; we use attention as proxy + keyword
        attn = self.explain_attention(text, top_k=top_k * 2)
        tokens = attn.get("top_tokens", [])

        # Boost clinical terms in ranking
        boosted = []
        for tok, score in tokens:
            extra = 0.15 if tok.lower() in self.high_risk_keywords else 0.0
            boosted.append((tok, score + extra))
        boosted = sorted(boosted, key=lambda x: x[1], reverse=True)[:top_k]

        return {
            "top_tokens": boosted,
            "method": "SHAP-style (attention + clinical keyword weighting)",
        }

    def explain_lime(self, text: str, top_k: int = 8) -> Dict:
        """LIME local explanation (paper method 2) – simplified"""
        if not HAS_LIME:
            return {"top_tokens": [], "method": "LIME (library not installed)"}

        # Lightweight version: use word-level importance via masking
        words = text.split()
        if len(words) < 2:
            return {"top_tokens": [], "method": "LIME (too short)"}

        base_pred = self.predict(text)
        base_score = list(base_pred["probabilities"].values())[-1]  # risk class

        importances = []
        for i, w in enumerate(words):
            masked = " ".join(words[:i] + ["[MASK]"] + words[i+1:])
            new_pred = self.predict(masked)
            new_score = list(new_pred["probabilities"].values())[-1]
            delta = base_score - new_score
            importances.append((w, float(delta)))

        ranked = sorted(importances, key=lambda x: abs(x[1]), reverse=True)[:top_k]
        return {
            "top_tokens": ranked,
            "method": "LIME-style (word masking importance)",
        }

    def full_explain(self, text: str) -> Dict:
        """Multi-layer explainability like the paper"""
        return {
            "attention": self.explain_attention(text),
            "shap": self.explain_shap(text),
            "lime": self.explain_lime(text),
        }


if __name__ == "__main__":
    cf = CrisisFormer("../config.yaml", num_labels=2)
    sample = "I feel completely hopeless and want to die. Nothing matters anymore."
    print(cf.predict(sample))
    print(cf.full_explain(sample))
