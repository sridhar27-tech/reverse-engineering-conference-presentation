"""
NeuroGuard XAI - Backend API
Run: uvicorn main:app --reload --port 8000
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Optional, List, Dict
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from pipeline import RiskPipeline

app = FastAPI(
    title="NeuroGuard XAI API",
    description="Backend for Reverse Engineering BERT-based Suicide Risk Classification",
    version="0.5.0"
)

# Allow frontend to call this API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load pipeline once
CONFIG_PATH = Path(__file__).resolve().parent.parent / "config.yaml"
pipeline = RiskPipeline(str(CONFIG_PATH))


class TextRequest(BaseModel):
    text: str = Field(..., min_length=1, max_length=2000, example="I feel hopeless and see no future.")
    explain: bool = True


class TokenScore(BaseModel):
    token: str
    score: float


class PredictionResponse(BaseModel):
    predicted_label: str
    probabilities: Dict[str, float]
    top_tokens: Optional[List[TokenScore]] = None
    high_risk_alert: bool
    disclaimer: str


@app.get("/")
def root():
    return {
        "message": "NeuroGuard XAI Backend is running",
        "status": "active",
        "docs": "/docs"
    }


@app.get("/health")
def health():
    return {"status": "healthy"}


@app.post("/predict", response_model=PredictionResponse)
def predict(request: TextRequest):
    if not request.text.strip():
        raise HTTPException(status_code=400, detail="Text cannot be empty")

    try:
        result = pipeline.run(request.text, explain=request.explain)

        top_tokens = None
        if result.get("explanation") and result["explanation"].get("top_tokens"):
            top_tokens = [
                {"token": t[0], "score": round(t[1], 4)}
                for t in result["explanation"]["top_tokens"][:8]
            ]

        return {
            "predicted_label": result["prediction"]["predicted_label"],
            "probabilities": result["prediction"]["probabilities"],
            "top_tokens": top_tokens,
            "high_risk_alert": result["flags"]["high_risk_alert"],
            "disclaimer": result["ethics"]["disclaimer"]
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)